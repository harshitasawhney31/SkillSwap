import test from 'node:test';
import assert from 'node:assert/strict';
import { db } from '../server/db.js';

test('Workflow A: Account creation, authentication, profile edit, and persistence', () => {
  const email = `test.student.a.${Date.now()}@university.edu`;
  const user = db.createUser({
    email,
    password: 'Password123!',
    name: 'Alice Cooper',
    university: 'Stanford University',
    major: 'Computer Science',
    graduationYear: 2026,
    bio: 'Excited to learn!',
  });

  assert.ok(user.id);
  assert.equal(user.email, email);

  // Authenticate
  const auth = db.authenticateUser(email, 'Password123!');
  assert.ok(auth.token);
  assert.equal(auth.user.id, user.id);

  // Update profile
  const updated = db.updateUserProfile(user.id, {
    bio: 'Updated bio: systems & web dev',
    major: 'Computer Science & AI',
  });
  assert.equal(updated.bio, 'Updated bio: systems & web dev');
  assert.equal(updated.major, 'Computer Science & AI');

  // Verify full profile retrieval
  const profile = db.getFullUserProfile(user.id);
  assert.equal(profile.bio, 'Updated bio: systems & web dev');

  // Logout / session destruction
  db.destroySession(auth.token);
  assert.equal(db.getUserBySession(auth.token), null);
});

test('Workflow B: Skills, Goals, and Reciprocal Discovery with dynamic score recalculation', () => {
  const emailA = `recip.a.${Date.now()}@uni.edu`;
  const emailB = `recip.b.${Date.now()}@uni.edu`;

  const userA = db.createUser({
    email: emailA,
    password: 'Password123!',
    name: 'Student Alpha',
    major: 'CS',
  });

  const userB = db.createUser({
    email: emailB,
    password: 'Password123!',
    name: 'Student Beta',
    major: 'CS',
  });

  // Student A teaches C++ and wants React
  db.createSkill(userA.id, { name: 'C++', category: 'Computer Science', proficiency: 'EXPERT' });
  db.createGoal(userA.id, { name: 'React', category: 'Computer Science', desiredLevel: 'INTERMEDIATE' });

  // Student B teaches React and wants C++
  const reactSkill = db.createSkill(userB.id, { name: 'React', category: 'Computer Science', proficiency: 'ADVANCED' });
  db.createGoal(userB.id, { name: 'C++', category: 'Computer Science', desiredLevel: 'BEGINNER' });

  // Check discovery from Student A's perspective
  let peers = db.getDiscoveredPeers(userA.id);
  let peerB = peers.find(p => p.id === userB.id);

  assert.ok(peerB, 'Peer B should be discovered');
  assert.equal(peerB.isReciprocal, true, 'Match must be reciprocal');
  assert.ok(peerB.matchScore >= 80, `Expected score >= 80, got ${peerB.matchScore}`);

  // Now Student B removes React teaching skill
  db.deleteSkill(userB.id, reactSkill.id);

  // Re-run discovery
  peers = db.getDiscoveredPeers(userA.id);
  peerB = peers.find(p => p.id === userB.id);

  assert.equal(peerB.isReciprocal, false, 'Should no longer be reciprocal');
  assert.ok(peerB.matchScore < 50, `Score should drop significantly, got ${peerB.matchScore}`);
});

test('Workflow C: Booking creation, acceptance, and collision rejection', () => {
  const emailA = `book.a.${Date.now()}@uni.edu`;
  const emailB = `book.b.${Date.now()}@uni.edu`;

  const userA = db.createUser({ email: emailA, password: 'Password123!', name: 'Booker A' });
  const userB = db.createUser({ email: emailB, password: 'Password123!', name: 'Booker B' });

  const bookingDate = '2027-11-20';

  // Student A requests booking with Student B
  const booking = db.createBookingRequest(userA.id, {
    recipientId: userB.id,
    skillName: 'C++',
    topic: 'Pointers and Memory',
    proposedDate: bookingDate,
    startTime: '14:00',
    endTime: '15:00',
  });

  assert.equal(booking.status, 'PENDING');

  // Student B accepts
  const accepted = db.updateBookingStatus(userB.id, booking.id, 'ACCEPTED');
  assert.equal(accepted.status, 'ACCEPTED');

  // Attempt overlapping booking on same date and time
  assert.throws(() => {
    db.createBookingRequest(userA.id, {
      recipientId: userB.id,
      skillName: 'Algorithms',
      proposedDate: bookingDate,
      startTime: '14:30',
      endTime: '15:30',
    });
  }, /Schedule conflict/i);

  // Complete the session
  const completed = db.updateBookingStatus(userB.id, booking.id, 'COMPLETED');
  assert.equal(completed.status, 'COMPLETED');
});

test('Workflow D: Persistent messaging, reviews, and rating aggregation', () => {
  const emailA = `msg.a.${Date.now()}@uni.edu`;
  const emailB = `msg.b.${Date.now()}@uni.edu`;

  const userA = db.createUser({ email: emailA, password: 'Password123!', name: 'Messenger A' });
  const userB = db.createUser({ email: emailB, password: 'Password123!', name: 'Messenger B' });

  // Send message from A to B
  const msg = db.sendMessage(userA.id, userB.id, 'Hello from Student A!');
  assert.equal(msg.content, 'Hello from Student A!');

  // Retrieve as Student B
  const convo = db.getConversation(userB.id, userA.id);
  assert.equal(convo.length, 1);
  assert.equal(convo[0].content, 'Hello from Student A!');

  // Complete a booking to test review
  const booking = db.createBookingRequest(userA.id, {
    recipientId: userB.id,
    skillName: 'React',
    proposedDate: '2027-11-22',
    startTime: '10:00',
    endTime: '11:00',
  });
  db.updateBookingStatus(userB.id, booking.id, 'ACCEPTED');
  db.updateBookingStatus(userB.id, booking.id, 'COMPLETED');

  // Submit 5-star review as Student A for Student B
  const review = db.createReview(userA.id, {
    bookingId: booking.id,
    rating: 5,
    feedback: 'Phenomenal tutor! Learned so much.',
  });
  assert.equal(review.rating, 5);

  // Verify Student B's updated profile reflects new rating and review count
  const updatedB = db.getUserById(userB.id);
  assert.equal(updatedB.averageRating, 5.0);
  assert.equal(updatedB.totalReviews, 1);
});

test('Workflow E: Authorization boundaries and privilege checks', () => {
  const emailA = `auth.a.${Date.now()}@uni.edu`;
  const emailB = `auth.b.${Date.now()}@uni.edu`;

  const userA = db.createUser({ email: emailA, password: 'Password123!', name: 'User A' });
  const userB = db.createUser({ email: emailB, password: 'Password123!', name: 'User B' });

  const skillB = db.createSkill(userB.id, { name: 'Python', category: 'CS' });

  // User A tries to delete User B's skill
  assert.throws(() => {
    db.deleteSkill(userA.id, skillB.id);
  }, /Unauthorized/i);

  // User A creates booking with User B
  const booking = db.createBookingRequest(userA.id, {
    recipientId: userB.id,
    skillName: 'Python',
    proposedDate: '2027-11-25',
    startTime: '16:00',
    endTime: '17:00',
  });

  // User A (requester) cannot accept their own booking request
  assert.throws(() => {
    db.updateBookingStatus(userA.id, booking.id, 'ACCEPTED');
  }, /Only the session recipient can accept/i);
});
