import test from 'node:test';
import assert from 'node:assert/strict';
import bcrypt from 'bcryptjs';

test('Workflow A: Password hashing and verification works securely', async () => {
  const password = 'SecretPassword123!';
  const salt = bcrypt.genSaltSync(10);
  const hash = bcrypt.hashSync(password, salt);

  assert.notEqual(hash, password);
  assert.ok(bcrypt.compareSync(password, hash));
  assert.ok(!bcrypt.compareSync('WrongPassword', hash));
});
