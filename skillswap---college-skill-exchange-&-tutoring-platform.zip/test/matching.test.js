import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateCompatibility } from '../server/matching.js';

test('Workflow B: Reciprocal matching identifies mutual compatibility', () => {
  const studentA = {
    id: 'user-a',
    name: 'Student A',
    teachingSkills: [{ name: 'C++', category: 'Computer Science', proficiency: 'EXPERT' }],
    learningGoals: [{ name: 'React', category: 'Computer Science', desiredLevel: 'INTERMEDIATE' }],
    availabilities: [{ dayOfWeek: 2, startTime: '14:00', endTime: '18:00' }],
    averageRating: 5.0,
  };

  const studentB = {
    id: 'user-b',
    name: 'Student B',
    teachingSkills: [{ name: 'React', category: 'Computer Science', proficiency: 'ADVANCED' }],
    learningGoals: [{ name: 'C++', category: 'Computer Science', desiredLevel: 'BEGINNER' }],
    availabilities: [{ dayOfWeek: 2, startTime: '15:00', endTime: '17:00' }],
    averageRating: 4.8,
  };

  const result = calculateCompatibility(studentA, studentB);

  // Reciprocal match should be true
  assert.equal(result.isReciprocal, true);
  assert.ok(result.score >= 80, `Expected score >= 80, got ${result.score}`);
  assert.ok(result.matchedTheyTeach.includes('React'));
  assert.ok(result.matchedYouTeach.includes('C++'));
  assert.ok(result.reasons.some(r => r.includes('Direct 2-way Swap')));
});

test('Workflow B: Removing a skill reduces or removes compatibility', () => {
  const studentA = {
    id: 'user-a',
    teachingSkills: [{ name: 'C++', category: 'Computer Science', proficiency: 'EXPERT' }],
    learningGoals: [{ name: 'React', category: 'Computer Science', desiredLevel: 'INTERMEDIATE' }],
    availabilities: [],
    averageRating: 0,
  };

  // Student B no longer has React as a teaching skill
  const studentBModified = {
    id: 'user-b',
    teachingSkills: [{ name: 'Python', category: 'Computer Science', proficiency: 'INTERMEDIATE' }],
    learningGoals: [{ name: 'C++', category: 'Computer Science', desiredLevel: 'BEGINNER' }],
    availabilities: [],
    averageRating: 0,
  };

  const result = calculateCompatibility(studentA, studentBModified);

  // No longer reciprocal
  assert.equal(result.isReciprocal, false);
  assert.equal(result.matchedTheyTeach.length, 0);
  assert.ok(result.score < 50, `Expected score < 50, got ${result.score}`);
});

test('Matching returns score 0 and empty reasons when completely unrelated', () => {
  const studentA = {
    id: 'user-a',
    teachingSkills: [{ name: 'Piano', category: 'Music', proficiency: 'EXPERT' }],
    learningGoals: [{ name: 'French', category: 'Languages', desiredLevel: 'BEGINNER' }],
    availabilities: [],
  };

  const studentC = {
    id: 'user-c',
    teachingSkills: [{ name: 'Linear Algebra', category: 'Math', proficiency: 'ADVANCED' }],
    learningGoals: [{ name: 'Chemistry', category: 'Science', desiredLevel: 'BEGINNER' }],
    availabilities: [],
  };

  const result = calculateCompatibility(studentA, studentC);
  assert.equal(result.score, 0);
  assert.equal(result.isReciprocal, false);
  assert.equal(result.reasons.length, 0);
});

test('Self matching returns score 0', () => {
  const user = {
    id: 'user-a',
    teachingSkills: [{ name: 'React', category: 'CS', proficiency: 'EXPERT' }],
    learningGoals: [{ name: 'React', category: 'CS', desiredLevel: 'EXPERT' }],
  };
  const result = calculateCompatibility(user, user);
  assert.equal(result.score, 0);
});
