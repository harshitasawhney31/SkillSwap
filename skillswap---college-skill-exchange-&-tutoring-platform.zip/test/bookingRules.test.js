import test from 'node:test';
import assert from 'node:assert/strict';
import { validateBookingRequest, validateStatusTransition } from '../server/bookingRules.js';

test('Workflow C: Booking rejects self-booking', () => {
  const req = {
    requesterId: 'user-1',
    recipientId: 'user-1',
    skillName: 'React',
    proposedDate: '2027-11-20',
    startTime: '14:00',
    endTime: '15:00',
  };
  const res = validateBookingRequest(req, []);
  assert.equal(res.valid, false);
  assert.match(res.error, /Self-booking is not allowed/i);
});

test('Workflow C: Booking rejects past dates', () => {
  const req = {
    requesterId: 'user-1',
    recipientId: 'user-2',
    skillName: 'React',
    proposedDate: '2020-01-01',
    startTime: '14:00',
    endTime: '15:00',
  };
  const res = validateBookingRequest(req, []);
  assert.equal(res.valid, false);
  assert.match(res.error, /Cannot book sessions in the past/i);
});

test('Workflow C: Booking rejects invalid time window', () => {
  const req = {
    requesterId: 'user-1',
    recipientId: 'user-2',
    skillName: 'React',
    proposedDate: '2027-12-01',
    startTime: '16:00',
    endTime: '14:00', // end before start
  };
  const res = validateBookingRequest(req, []);
  assert.equal(res.valid, false);
  assert.match(res.error, /End time must be after start time/i);
});

test('Workflow C: Overlapping booking collision is rejected', () => {
  const existingBookings = [
    {
      id: 'book-1',
      requesterId: 'user-3',
      recipientId: 'user-2',
      status: 'ACCEPTED',
      proposedDate: '2027-11-15',
      startTime: '14:00',
      endTime: '15:30',
    },
  ];

  const collidingReq = {
    requesterId: 'user-1',
    recipientId: 'user-2',
    skillName: 'Physics',
    proposedDate: '2027-11-15',
    startTime: '15:00', // overlaps 14:00-15:30
    endTime: '16:00',
  };

  const res = validateBookingRequest(collidingReq, existingBookings);
  assert.equal(res.valid, false);
  assert.match(res.error, /Schedule conflict/i);
});

test('Workflow C: State transition authorization - non-participant cannot accept', () => {
  const booking = {
    id: 'b-1',
    requesterId: 'user-a',
    recipientId: 'user-b',
    status: 'PENDING',
    proposedDate: '2027-11-15',
    startTime: '14:00',
    endTime: '15:00',
  };

  // User C tries to accept
  const authRes = validateStatusTransition(booking, 'ACCEPTED', 'user-c', []);
  assert.equal(authRes.allowed, false);
  assert.match(authRes.error, /Unauthorized/i);

  // Requester (User A) cannot accept their own request
  const reqRes = validateStatusTransition(booking, 'ACCEPTED', 'user-a', []);
  assert.equal(reqRes.allowed, false);
  assert.match(reqRes.error, /Only the session recipient can accept/i);

  // Recipient (User B) can accept
  const okRes = validateStatusTransition(booking, 'ACCEPTED', 'user-b', []);
  assert.equal(okRes.allowed, true);
});
