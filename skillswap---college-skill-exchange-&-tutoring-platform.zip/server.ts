import express from 'express';
import cookieParser from 'cookie-parser';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { db } from './server/db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

app.use(express.json());
app.use(cookieParser());

// Auth Extraction Middleware
function extractUser(req: any, _res: any, next: any) {
  const authHeader = req.headers.authorization;
  let token = null;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.substring(7);
  } else if (req.cookies && req.cookies.sk_sess_token) {
    token = req.cookies.sk_sess_token;
  }

  if (token) {
    const user = db.getUserBySession(token);
    if (user) {
      req.user = user;
      req.sessionToken = token;
    }
  }
  next();
}

// Strict Authorization Guard
function requireAuth(req: any, res: any, next: any) {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required. Please log in.' });
  }
  next();
}

app.use(extractUser);

// -----------------------------------------------------------------------------
// AUTHENTICATION & USER ACCOUNTS
// -----------------------------------------------------------------------------

// Register
app.post('/api/auth/register', (req, res) => {
  try {
    const { email, password, name, university, major, graduationYear, bio, avatarUrl } = req.body;
    if (!email || !password || !name) {
      return res.status(400).json({ error: 'Email, password, and full name are required.' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters.' });
    }

    const newUser = db.createUser({
      email,
      password,
      name,
      university,
      major,
      graduationYear,
      bio,
      avatarUrl,
    });

    const { user, token } = db.authenticateUser(email, password);
    res.cookie('sk_sess_token', token, {
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    return res.status(201).json({ user, token });
  } catch (err: any) {
    if (err.message && err.message.includes('already exists')) {
      return res.status(409).json({ error: err.message });
    }
    return res.status(400).json({ error: err.message || 'Registration failed.' });
  }
});

// Login
app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const { user, token } = db.authenticateUser(email, password);
    res.cookie('sk_sess_token', token, {
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    return res.json({ user, token });
  } catch (err: any) {
    return res.status(401).json({ error: err.message || 'Invalid credentials.' });
  }
});

// Logout
app.post('/api/auth/logout', (req: any, res) => {
  if (req.sessionToken) {
    db.destroySession(req.sessionToken);
  }
  res.clearCookie('sk_sess_token');
  return res.json({ success: true, message: 'Logged out successfully.' });
});

// Current User Profile
app.get('/api/auth/me', (req: any, res) => {
  if (!req.user) {
    return res.status(401).json({ user: null });
  }
  const fullProfile = db.getFullUserProfile(req.user.id);
  return res.json({ user: fullProfile });
});

// Update Profile
app.put('/api/auth/profile', requireAuth, (req: any, res) => {
  try {
    const updated = db.updateUserProfile(req.user.id, req.body);
    const fullProfile = db.getFullUserProfile(req.user.id);
    return res.json({ user: fullProfile, message: 'Profile updated successfully.' });
  } catch (err: any) {
    return res.status(400).json({ error: err.message || 'Failed to update profile.' });
  }
});

// Change Password
app.post('/api/auth/change-password', requireAuth, (req: any, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: 'Current password and new password are required.' });
    }
    db.changeUserPassword(req.user.id, currentPassword, newPassword);
    return res.json({ success: true, message: 'Password updated successfully.' });
  } catch (err: any) {
    return res.status(400).json({ error: err.message || 'Failed to change password.' });
  }
});

// Delete Account
app.delete('/api/auth/account', requireAuth, (req: any, res) => {
  try {
    db.deleteUserAccount(req.user.id);
    if (req.sessionToken) {
      db.destroySession(req.sessionToken);
    }
    res.clearCookie('sk_sess_token');
    return res.json({ success: true, message: 'Account permanently deleted.' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Failed to delete account.' });
  }
});

// Test student switcher helper (allows quick testing of multi-account workflows A-E)
app.get('/api/test-students', (_req, res) => {
  const students = [
    { email: 'alex.rivera@university.edu', name: 'Alex Rivera (C++ Tutor, wants React)', major: 'Computer Science' },
    { email: 'priya.patel@university.edu', name: 'Priya Patel (React Tutor, wants C++)', major: 'Software Engineering' },
    { email: 'jordan.lee@university.edu', name: 'Jordan Lee (Linear Algebra, wants Python)', major: 'Applied Mathematics' },
    { email: 'marcus.chen@university.edu', name: 'Marcus Chen (Figma UI/UX, wants Math)', major: 'Cognitive Science' },
  ];
  return res.json({ students, defaultPassword: 'password123' });
});

// -----------------------------------------------------------------------------
// SKILLS MANAGEMENT
// -----------------------------------------------------------------------------

app.get('/api/skills', requireAuth, (req: any, res) => {
  const skills = db.getUserSkills(req.user.id);
  return res.json({ skills });
});

app.post('/api/skills', requireAuth, (req: any, res) => {
  try {
    const newSkill = db.createSkill(req.user.id, req.body);
    return res.status(201).json({ skill: newSkill, message: 'Teaching skill added.' });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

app.put('/api/skills/:id', requireAuth, (req: any, res) => {
  try {
    const updated = db.updateSkill(req.user.id, req.params.id, req.body);
    return res.json({ skill: updated, message: 'Skill updated.' });
  } catch (err: any) {
    if (err.message && err.message.includes('Unauthorized')) {
      return res.status(403).json({ error: err.message });
    }
    return res.status(400).json({ error: err.message });
  }
});

app.delete('/api/skills/:id', requireAuth, (req: any, res) => {
  try {
    db.deleteSkill(req.user.id, req.params.id);
    return res.json({ success: true, message: 'Skill removed.' });
  } catch (err: any) {
    if (err.message && err.message.includes('Unauthorized')) {
      return res.status(403).json({ error: err.message });
    }
    return res.status(400).json({ error: err.message });
  }
});

app.post('/api/skills/:id/convert-to-goal', requireAuth, (req: any, res) => {
  try {
    const newGoal = db.convertSkillToGoal(req.user.id, req.params.id, req.body);
    return res.json({ goal: newGoal, message: 'Shifted from teaching skill to learning goal.' });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

// -----------------------------------------------------------------------------
// LEARNING GOALS MANAGEMENT
// -----------------------------------------------------------------------------

app.get('/api/goals', requireAuth, (req: any, res) => {
  const goals = db.getUserGoals(req.user.id);
  return res.json({ goals });
});

app.post('/api/goals', requireAuth, (req: any, res) => {
  try {
    const newGoal = db.createGoal(req.user.id, req.body);
    return res.status(201).json({ goal: newGoal, message: 'Learning goal added.' });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

app.put('/api/goals/:id', requireAuth, (req: any, res) => {
  try {
    const updated = db.updateGoal(req.user.id, req.params.id, req.body);
    return res.json({ goal: updated, message: 'Learning goal updated.' });
  } catch (err: any) {
    if (err.message && err.message.includes('Unauthorized')) {
      return res.status(403).json({ error: err.message });
    }
    return res.status(400).json({ error: err.message });
  }
});

app.delete('/api/goals/:id', requireAuth, (req: any, res) => {
  try {
    db.deleteGoal(req.user.id, req.params.id);
    return res.json({ success: true, message: 'Learning goal removed.' });
  } catch (err: any) {
    if (err.message && err.message.includes('Unauthorized')) {
      return res.status(403).json({ error: err.message });
    }
    return res.status(400).json({ error: err.message });
  }
});

app.post('/api/goals/:id/convert-to-skill', requireAuth, (req: any, res) => {
  try {
    const newSkill = db.convertGoalToSkill(req.user.id, req.params.id, req.body);
    return res.json({ skill: newSkill, message: 'Shifted from learning goal to teaching skill.' });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

// -----------------------------------------------------------------------------
// AVAILABILITY
// -----------------------------------------------------------------------------

app.get('/api/availability', requireAuth, (req: any, res) => {
  const availabilities = db.getAvailabilities(req.user.id);
  return res.json({ availabilities });
});

app.put('/api/availability', requireAuth, (req: any, res) => {
  try {
    const slots = req.body.slots || [];
    const updated = db.setAvailabilities(req.user.id, slots);
    return res.json({ availabilities: updated, message: 'Availability schedule updated.' });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

// -----------------------------------------------------------------------------
// PEER DISCOVERY & RECIPROCAL MATCHING
// -----------------------------------------------------------------------------

app.get('/api/peers/discover', requireAuth, (req: any, res) => {
  try {
    const peers = db.getDiscoveredPeers(req.user.id, req.query);
    return res.json({ peers });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

app.get('/api/peers/:id', requireAuth, (req: any, res) => {
  try {
    const peer = db.getFullUserProfile(req.params.id);
    if (!peer) return res.status(404).json({ error: 'Peer student not found.' });
    return res.json({ peer });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// -----------------------------------------------------------------------------
// BOOKINGS & CALENDAR
// -----------------------------------------------------------------------------

app.get('/api/bookings', requireAuth, (req: any, res) => {
  try {
    const bookings = db.getBookingsForUser(req.user.id);
    return res.json({ bookings });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

app.post('/api/bookings', requireAuth, (req: any, res) => {
  try {
    const booking = db.createBookingRequest(req.user.id, req.body);
    return res.status(201).json({ booking, message: 'Session booking request created successfully.' });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

app.patch('/api/bookings/:id/status', requireAuth, (req: any, res) => {
  try {
    const { status } = req.body;
    if (!status) return res.status(400).json({ error: 'Status is required.' });

    const updated = db.updateBookingStatus(req.user.id, req.params.id, status);
    return res.json({ booking: updated, message: `Booking status changed to ${status}.` });
  } catch (err: any) {
    if (err.message && (err.message.includes('Unauthorized') || err.message.includes('Only the session recipient'))) {
      return res.status(403).json({ error: err.message });
    }
    return res.status(400).json({ error: err.message });
  }
});

// -----------------------------------------------------------------------------
// MESSAGING
// -----------------------------------------------------------------------------

app.get('/api/messages', requireAuth, (req: any, res) => {
  try {
    const conversations = db.getConversationsList(req.user.id);
    return res.json({ conversations });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

app.get('/api/messages/:peerId', requireAuth, (req: any, res) => {
  try {
    const messages = db.getConversation(req.user.id, req.params.peerId);
    db.markConversationRead(req.user.id, req.params.peerId);
    return res.json({ messages });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

app.post('/api/messages/:peerId', requireAuth, (req: any, res) => {
  try {
    const { content } = req.body;
    const message = db.sendMessage(req.user.id, req.params.peerId, content);
    return res.status(201).json({ message });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

// -----------------------------------------------------------------------------
// REVIEWS & RATINGS
// -----------------------------------------------------------------------------

app.get('/api/reviews', requireAuth, (req: any, res) => {
  try {
    const reviews = db.getUserReviews(req.user.id);
    return res.json({ reviews });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

app.post('/api/reviews', requireAuth, (req: any, res) => {
  try {
    const review = db.createReview(req.user.id, req.body);
    return res.status(201).json({ review, message: 'Review submitted successfully.' });
  } catch (err: any) {
    if (err.message && err.message.includes('Unauthorized')) {
      return res.status(403).json({ error: err.message });
    }
    return res.status(400).json({ error: err.message });
  }
});

// -----------------------------------------------------------------------------
// NOTIFICATIONS
// -----------------------------------------------------------------------------

app.get('/api/notifications', requireAuth, (req: any, res) => {
  try {
    const notifications = db.getNotifications(req.user.id);
    return res.json({ notifications });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

app.patch('/api/notifications/:id/read', requireAuth, (req: any, res) => {
  db.markNotificationRead(req.user.id, req.params.id);
  return res.json({ success: true });
});

app.post('/api/notifications/read-all', requireAuth, (req: any, res) => {
  db.markAllNotificationsRead(req.user.id);
  return res.json({ success: true });
});

// -----------------------------------------------------------------------------
// PREFERENCES
// -----------------------------------------------------------------------------

app.get('/api/preferences', requireAuth, (req: any, res) => {
  const preferences = db.getUserPreferences(req.user.id);
  return res.json({ preferences });
});

app.put('/api/preferences', requireAuth, (req: any, res) => {
  try {
    const updated = db.updateUserPreferences(req.user.id, req.body);
    return res.json({ preferences: updated, message: 'Preferences updated.' });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
});

// -----------------------------------------------------------------------------
// VITE DEV SERVER / STATIC SERVING
// -----------------------------------------------------------------------------

async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SkillSwap full-stack server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});
