import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  Compass, 
  Sparkles, 
  Calendar, 
  MessageSquare, 
  User as UserIcon, 
  Bell, 
  LogOut, 
  CheckCheck,
  Users,
  ChevronDown
} from 'lucide-react';
import { Notification } from '../types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenAuth: () => void;
}

export function Navbar({ activeTab, setActiveTab, onOpenAuth }: NavbarProps) {
  const { user, logout, demoStudents, switchTestStudent } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [unreadMsgCount, setUnreadMsgCount] = useState(0);
  const notifRef = useRef<HTMLDivElement>(null);
  const userMenuRef = useRef<HTMLDivElement>(null);

  const fetchNotifications = async () => {
    if (!user) return;
    try {
      const token = localStorage.getItem('sk_token');
      const res = await fetch('/api/notifications', {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (res.ok) {
        const data = await res.json();
        setNotifications(data.notifications || []);
      }
    } catch (err) {
      console.error('Failed to load notifications:', err);
    }
  };

  const fetchUnreadMessages = async () => {
    if (!user) return;
    try {
      const token = localStorage.getItem('sk_token');
      const res = await fetch('/api/messages', {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (res.ok) {
        const data = await res.json();
        const count = (data.conversations || []).reduce((acc: number, c: any) => acc + (c.unreadCount || 0), 0);
        setUnreadMsgCount(count);
      }
    } catch (err) {
      console.error('Failed to load unread messages:', err);
    }
  };

  useEffect(() => {
    if (user) {
      fetchNotifications();
      fetchUnreadMessages();
      const interval = setInterval(() => {
        fetchNotifications();
        fetchUnreadMessages();
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [user]);

  // Click outside listener
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setShowUserMenu(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const markAllRead = async () => {
    try {
      const token = localStorage.getItem('sk_token');
      await fetch('/api/notifications/read-all', {
        method: 'POST',
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    } catch (err) {
      console.error('Error marking read:', err);
    }
  };

  const unreadNotifs = notifications.filter(n => !n.read).length;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Brand */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('discover')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
                  SkillSwap
                </span>
                <span className="px-2 py-0.5 text-[10px] font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded-full">
                  Campus Verified
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">Peer Tutoring & Reciprocal Skill Exchange</p>
            </div>
          </div>

          {/* Navigation Links (when authenticated) */}
          {user ? (
            <nav className="hidden md:flex items-center gap-1 bg-slate-900/60 p-1 rounded-xl border border-slate-800/60">
              <button
                onClick={() => setActiveTab('discover')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeTab === 'discover'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                }`}
              >
                <Compass className="w-4 h-4" />
                Discover Peers
              </button>

              <button
                onClick={() => setActiveTab('skills')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeTab === 'skills'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                }`}
              >
                <Sparkles className="w-4 h-4" />
                My Skills & Goals
              </button>

              <button
                onClick={() => setActiveTab('bookings')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeTab === 'bookings'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                }`}
              >
                <Calendar className="w-4 h-4" />
                Sessions & Calendar
              </button>

              <button
                onClick={() => setActiveTab('messages')}
                className={`relative flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeTab === 'messages'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                }`}
              >
                <MessageSquare className="w-4 h-4" />
                Messages
                {unreadMsgCount > 0 && (
                  <span className="ml-1 px-1.5 py-0.2 text-[10px] font-bold bg-cyan-500 text-slate-950 rounded-full animate-pulse">
                    {unreadMsgCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => setActiveTab('profile')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeTab === 'profile'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                }`}
              >
                <UserIcon className="w-4 h-4" />
                Profile
              </button>
            </nav>
          ) : null}

          {/* Right Action Bar */}
          <div className="flex items-center gap-3">
            {user ? (
              <>
                {/* Notifications Bell */}
                <div className="relative" ref={notifRef}>
                  <button
                    onClick={() => setShowNotifications(!showNotifications)}
                    className="relative p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-900 border border-slate-800 transition"
                    aria-label="View notifications"
                  >
                    <Bell className="w-5 h-5" />
                    {unreadNotifs > 0 && (
                      <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white ring-2 ring-slate-950">
                        {unreadNotifs}
                      </span>
                    )}
                  </button>

                  {/* Notifications Popover */}
                  {showNotifications && (
                    <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-xl bg-slate-900 border border-slate-800 shadow-2xl p-3 z-50 animate-in fade-in slide-in-from-top-2">
                      <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-sm text-white">Notifications</span>
                          {unreadNotifs > 0 && (
                            <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 font-mono">
                              {unreadNotifs} new
                            </span>
                          )}
                        </div>
                        {unreadNotifs > 0 && (
                          <button
                            onClick={markAllRead}
                            className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
                          >
                            <CheckCheck className="w-3.5 h-3.5" />
                            Mark all read
                          </button>
                        )}
                      </div>

                      <div className="max-h-72 overflow-y-auto space-y-2 divide-y divide-slate-800/50">
                        {notifications.length === 0 ? (
                          <p className="text-xs text-slate-500 text-center py-6">No notifications yet.</p>
                        ) : (
                          notifications.map(n => (
                            <div
                              key={n.id}
                              onClick={() => {
                                if (n.link === '/bookings') setActiveTab('bookings');
                                if (n.link === '/messages') setActiveTab('messages');
                                if (n.link === '/profile') setActiveTab('profile');
                                setShowNotifications(false);
                              }}
                              className={`pt-2 cursor-pointer transition p-2 rounded-lg ${
                                !n.read ? 'bg-indigo-500/10 hover:bg-indigo-500/15' : 'hover:bg-slate-800/40'
                              }`}
                            >
                              <div className="flex items-start justify-between gap-2">
                                <h4 className="text-xs font-semibold text-slate-200">{n.title}</h4>
                                <span className="text-[10px] text-slate-500 shrink-0">
                                  {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">{n.message}</p>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* User Dropdown / Test Switcher */}
                <div className="relative" ref={userMenuRef}>
                  <button
                    onClick={() => setShowUserMenu(!showUserMenu)}
                    className="flex items-center gap-2.5 p-1.5 pr-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition"
                  >
                    <img
                      src={user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80'}
                      alt={user.name}
                      className="w-7 h-7 rounded-lg object-cover ring-1 ring-indigo-500/40"
                    />
                    <div className="text-left hidden sm:block">
                      <div className="text-xs font-semibold text-slate-200 truncate max-w-[110px]">{user.name}</div>
                      <div className="text-[10px] text-slate-400 truncate max-w-[110px]">{user.major}</div>
                    </div>
                    <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                  </button>

                  {/* Dropdown Menu with Switch Student Account */}
                  {showUserMenu && (
                    <div className="absolute right-0 mt-2 w-72 rounded-xl bg-slate-900 border border-slate-800 shadow-2xl p-2 z-50 animate-in fade-in slide-in-from-top-2">
                      <div className="p-2 border-b border-slate-800 mb-2">
                        <div className="text-xs font-bold text-white">{user.name}</div>
                        <div className="text-[11px] text-slate-400">{user.email}</div>
                        <div className="flex items-center gap-1.5 mt-1.5 text-[11px] text-emerald-400 font-medium">
                          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                          {user.university}
                        </div>
                      </div>

                      {/* Fast Student Account Switcher */}
                      <div className="mb-2 p-1.5 bg-slate-950/70 rounded-lg border border-slate-800/80">
                        <div className="flex items-center gap-1.5 text-[10px] font-bold text-indigo-300 uppercase tracking-wider mb-1.5 px-1">
                          <Users className="w-3 h-3 text-indigo-400" />
                          Switch Testing Account
                        </div>
                        <div className="space-y-1">
                          {demoStudents.map(demo => (
                            <button
                              key={demo.email}
                              disabled={demo.email === user.email}
                              onClick={async () => {
                                await switchTestStudent(demo.email);
                                setShowUserMenu(false);
                              }}
                              className={`w-full text-left px-2 py-1.5 rounded text-xs transition flex items-center justify-between ${
                                demo.email === user.email
                                  ? 'bg-indigo-600/20 text-indigo-300 font-semibold cursor-default'
                                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                              }`}
                            >
                              <span className="truncate">{demo.name}</span>
                              {demo.email === user.email && <span className="text-[10px] text-indigo-400 shrink-0">Current</span>}
                            </button>
                          ))}
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          setActiveTab('profile');
                          setShowUserMenu(false);
                        }}
                        className="w-full text-left px-2 py-1.5 rounded-lg text-xs text-slate-300 hover:bg-slate-800 hover:text-white flex items-center gap-2"
                      >
                        <UserIcon className="w-3.5 h-3.5 text-slate-400" />
                        Account Settings
                      </button>

                      <button
                        onClick={async () => {
                          await logout();
                          setShowUserMenu(false);
                        }}
                        className="w-full text-left px-2 py-1.5 rounded-lg text-xs text-rose-400 hover:bg-rose-500/10 flex items-center gap-2 mt-1 border-t border-slate-800 pt-2"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        Sign Out
                      </button>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <button
                onClick={onOpenAuth}
                className="px-4 py-2 text-sm font-semibold rounded-xl bg-indigo-600 text-white hover:bg-indigo-500 shadow-md shadow-indigo-600/30 transition"
              >
                Sign In / Join
              </button>
            )}
          </div>
        </div>

        {/* Mobile Navigation Bar */}
        {user && (
          <div className="flex md:hidden items-center justify-around py-2 border-t border-slate-800/60 overflow-x-auto">
            <button
              onClick={() => setActiveTab('discover')}
              className={`p-2 rounded-lg text-xs flex flex-col items-center gap-1 ${
                activeTab === 'discover' ? 'text-indigo-400 font-semibold' : 'text-slate-400'
              }`}
            >
              <Compass className="w-4 h-4" />
              Discover
            </button>
            <button
              onClick={() => setActiveTab('skills')}
              className={`p-2 rounded-lg text-xs flex flex-col items-center gap-1 ${
                activeTab === 'skills' ? 'text-indigo-400 font-semibold' : 'text-slate-400'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              Skills
            </button>
            <button
              onClick={() => setActiveTab('bookings')}
              className={`p-2 rounded-lg text-xs flex flex-col items-center gap-1 ${
                activeTab === 'bookings' ? 'text-indigo-400 font-semibold' : 'text-slate-400'
              }`}
            >
              <Calendar className="w-4 h-4" />
              Sessions
            </button>
            <button
              onClick={() => setActiveTab('messages')}
              className={`p-2 rounded-lg text-xs flex flex-col items-center gap-1 relative ${
                activeTab === 'messages' ? 'text-indigo-400 font-semibold' : 'text-slate-400'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              Messages
              {unreadMsgCount > 0 && (
                <span className="absolute top-1 right-2 w-2 h-2 rounded-full bg-cyan-400" />
              )}
            </button>
            <button
              onClick={() => setActiveTab('profile')}
              className={`p-2 rounded-lg text-xs flex flex-col items-center gap-1 ${
                activeTab === 'profile' ? 'text-indigo-400 font-semibold' : 'text-slate-400'
              }`}
            >
              <UserIcon className="w-4 h-4" />
              Profile
            </button>
          </div>
        )}

      </div>
    </header>
  );
}
