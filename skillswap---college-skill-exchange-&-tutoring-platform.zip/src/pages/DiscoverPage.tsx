import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { PeerProfile } from '../types';
import { BookingModal } from '../components/BookingModal';
import { 
  Search, 
  Sparkles, 
  ArrowLeftRight, 
  GraduationCap, 
  Star, 
  Calendar, 
  MessageSquare, 
  Layers, 
  CheckCircle2, 
  Filter,
  UserCheck
} from 'lucide-react';

interface DiscoverPageProps {
  onOpenMessage: (peerId: string) => void;
  onNavigateToSkills: () => void;
}

export function DiscoverPage({ onOpenMessage, onNavigateToSkills }: DiscoverPageProps) {
  const { user } = useAuth();
  const [peers, setPeers] = useState<PeerProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [onlyReciprocal, setOnlyReciprocal] = useState(false);
  const [selectedPeerForBooking, setSelectedPeerForBooking] = useState<PeerProfile | null>(null);

  const categories = [
    'All',
    'Computer Science',
    'Mathematics',
    'Design & Frontend',
    'Languages',
    'Business',
    'Engineering',
  ];

  const fetchPeers = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('sk_token');
      const params = new URLSearchParams();
      if (searchQuery.trim()) params.set('skill', searchQuery.trim());
      if (selectedCategory !== 'All') params.set('category', selectedCategory);

      const res = await fetch(`/api/peers/discover?${params.toString()}`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });

      if (res.ok) {
        const data = await res.json();
        setPeers(data.peers || []);
      }
    } catch (err) {
      console.error('Failed to fetch discovered peers:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPeers();
  }, [searchQuery, selectedCategory]);

  const filteredPeers = onlyReciprocal ? peers.filter(p => p.isReciprocal) : peers;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in">
      
      {/* Hero / Header Banner */}
      <div className="relative rounded-3xl bg-gradient-to-r from-indigo-950/70 via-slate-900 to-slate-950 border border-indigo-500/20 p-6 sm:p-8 mb-8 overflow-hidden">
        <div className="absolute -right-10 -bottom-10 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 text-xs font-semibold mb-3">
            <ArrowLeftRight className="w-3.5 h-3.5" />
            Reciprocal Skill Exchange Engine
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Find Compatible Study Partners & Peer Tutors
          </h1>
          <p className="text-sm text-slate-300 mt-2 leading-relaxed">
            SkillSwap analyzes your teaching proficiencies and learning goals against fellow students to match reciprocal skill exchanges. Learn what you need, share what you know.
          </p>

          <div className="mt-4 flex flex-wrap items-center gap-3">
            <button
              onClick={onNavigateToSkills}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/30 transition"
            >
              <Sparkles className="w-4 h-4" />
              Manage My Skills & Goals
            </button>
            <span className="text-xs text-slate-400">
              Your profile: <strong className="text-slate-200">{user?.teachingSkills?.length || 0} skills</strong> teaching, <strong className="text-slate-200">{user?.learningGoals?.length || 0} goals</strong> learning
            </span>
          </div>
        </div>
      </div>

      {/* Filter and Search Controls */}
      <div className="space-y-4 mb-8">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Search Bar */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search skill (e.g., React, C++, Linear Algebra, Figma)..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Reciprocal Only Toggle */}
          <button
            onClick={() => setOnlyReciprocal(!onlyReciprocal)}
            className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-semibold border transition ${
              onlyReciprocal
                ? 'bg-indigo-600 text-white border-indigo-500 shadow-md shadow-indigo-600/20'
                : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
            }`}
          >
            <ArrowLeftRight className="w-3.5 h-3.5" />
            Only 2-Way Reciprocal Matches
          </button>
        </div>

        {/* Category Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition ${
                selectedCategory === cat
                  ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/40'
                  : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Peer Cards Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-72 rounded-2xl bg-slate-900/50 border border-slate-800 animate-pulse" />
          ))}
        </div>
      ) : filteredPeers.length === 0 ? (
        <div className="text-center py-16 px-4 rounded-3xl bg-slate-900/40 border border-slate-800">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-slate-800 flex items-center justify-center text-slate-500 mb-4">
            <Filter className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-white">No Matching Students Found</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto mt-1 mb-6">
            Try adjusting your search query, selecting "All" categories, or add more skills and learning goals to your profile to expand your matches.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('All');
              setOnlyReciprocal(false);
            }}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPeers.map(peer => (
            <div
              key={peer.id}
              className={`relative rounded-2xl bg-slate-900 border p-5 flex flex-col justify-between transition-all hover:border-indigo-500/40 hover:shadow-xl hover:shadow-indigo-500/5 ${
                peer.isReciprocal ? 'border-indigo-500/40 ring-1 ring-indigo-500/20' : 'border-slate-800'
              }`}
            >
              <div>
                {/* Header: Avatar, Name, Reciprocal badge */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={peer.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                      alt={peer.name}
                      className="w-12 h-12 rounded-xl object-cover ring-2 ring-slate-800"
                    />
                    <div>
                      <h3 className="font-bold text-sm text-white">{peer.name}</h3>
                      <div className="flex items-center gap-1.5 text-xs text-slate-400">
                        <GraduationCap className="w-3.5 h-3.5 text-slate-500" />
                        <span>{peer.major}</span>
                      </div>
                      <div className="text-[11px] text-slate-500">{peer.university}</div>
                    </div>
                  </div>

                  {/* Compatibility Badge */}
                  <div className="text-right">
                    <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 font-bold text-xs">
                      <Sparkles className="w-3 h-3 text-indigo-400" />
                      {peer.matchScore}%
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-amber-400 font-semibold justify-end mt-1">
                      <Star className="w-3 h-3 fill-amber-400" />
                      <span>{peer.averageRating > 0 ? peer.averageRating.toFixed(1) : 'New'}</span>
                      <span className="text-slate-500">({peer.totalReviews})</span>
                    </div>
                  </div>
                </div>

                {/* Reciprocal Tag */}
                {peer.isReciprocal && (
                  <div className="mb-3 px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-[11px] font-semibold flex items-center gap-1.5">
                    <ArrowLeftRight className="w-3.5 h-3.5 text-emerald-400" />
                    <span>2-Way Reciprocal Swap Match!</span>
                  </div>
                )}

                {/* Match Reasons List */}
                {peer.matchReasons && peer.matchReasons.length > 0 && (
                  <div className="mb-3.5 p-2.5 rounded-xl bg-slate-950/80 border border-slate-800/80 space-y-1">
                    <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                      Why you match:
                    </div>
                    {peer.matchReasons.slice(0, 2).map((reason, idx) => (
                      <div key={idx} className="flex items-start gap-1.5 text-xs text-slate-300">
                        <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400 shrink-0 mt-0.5" />
                        <span className="line-clamp-2">{reason}</span>
                      </div>
                    ))}
                  </div>
                )}

                {/* Skills they teach */}
                <div className="mb-3">
                  <div className="text-[11px] font-semibold text-slate-400 mb-1.5 flex items-center gap-1">
                    <Layers className="w-3 h-3 text-indigo-400" />
                    <span>Teaches ({peer.teachingSkills?.length || 0}):</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {(peer.teachingSkills || []).map(skill => (
                      <span
                        key={skill.id}
                        className="px-2 py-0.5 rounded-lg text-xs bg-slate-800 text-slate-200 border border-slate-700 font-medium"
                      >
                        {skill.name} <span className="text-[10px] text-slate-400">({skill.proficiency})</span>
                      </span>
                    ))}
                    {(peer.teachingSkills || []).length === 0 && (
                      <span className="text-xs text-slate-500 italic">No teaching skills listed yet</span>
                    )}
                  </div>
                </div>

                {/* Learning Goals */}
                <div className="mb-4">
                  <div className="text-[11px] font-semibold text-slate-400 mb-1.5 flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-cyan-400" />
                    <span>Wants to Learn:</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {(peer.learningGoals || []).map(goal => (
                      <span
                        key={goal.id}
                        className="px-2 py-0.5 rounded-lg text-xs bg-slate-800/60 text-cyan-200 border border-cyan-800/40"
                      >
                        {goal.name}
                      </span>
                    ))}
                    {(peer.learningGoals || []).length === 0 && (
                      <span className="text-xs text-slate-500 italic">No learning goals listed yet</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-2 pt-3 border-t border-slate-800/80">
                <button
                  onClick={() => setSelectedPeerForBooking(peer)}
                  className="w-full py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/20 transition flex items-center justify-center gap-1.5"
                >
                  <Calendar className="w-3.5 h-3.5" />
                  Request Session
                </button>
                <button
                  onClick={() => onOpenMessage(peer.id)}
                  className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition flex items-center justify-center gap-1.5"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  Chat
                </button>
              </div>

            </div>
          ))}
        </div>
      )}

      {/* Booking Modal */}
      {selectedPeerForBooking && (
        <BookingModal
          peer={selectedPeerForBooking}
          isOpen={Boolean(selectedPeerForBooking)}
          onClose={() => setSelectedPeerForBooking(null)}
          onSuccess={() => {
            fetchPeers();
          }}
        />
      )}

    </div>
  );
}
