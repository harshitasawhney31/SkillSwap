import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { Message, ConversationItem } from '../types';
import { MessageSquare, Send, User as UserIcon, AlertCircle, RefreshCw } from 'lucide-react';

interface MessagesPageProps {
  initialPeerId?: string | null;
}

export function MessagesPage({ initialPeerId }: MessagesPageProps) {
  const { user } = useAuth();
  const [conversations, setConversations] = useState<ConversationItem[]>([]);
  const [activePeerId, setActivePeerId] = useState<string | null>(initialPeerId || null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [messageInput, setMessageInput] = useState('');
  const [loadingConvos, setLoadingConvos] = useState(true);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const fetchConversations = async () => {
    try {
      const token = localStorage.getItem('sk_token');
      const res = await fetch('/api/messages', {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (res.ok) {
        const data = await res.json();
        setConversations(data.conversations || []);

        // If no active peer is selected and conversations exist, select the first one
        if (!activePeerId && (data.conversations || []).length > 0) {
          setActivePeerId(data.conversations[0].peer.id);
        }
      }
    } catch (err) {
      console.error('Failed to load conversations:', err);
    } finally {
      setLoadingConvos(false);
    }
  };

  const fetchActiveMessages = async (peerId: string) => {
    try {
      const token = localStorage.getItem('sk_token');
      const res = await fetch(`/api/messages/${peerId}`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (res.ok) {
        const data = await res.json();
        setMessages(data.messages || []);
      }
    } catch (err) {
      console.error('Failed to load messages:', err);
    }
  };

  useEffect(() => {
    fetchConversations();
  }, []);

  useEffect(() => {
    if (initialPeerId) {
      setActivePeerId(initialPeerId);
    }
  }, [initialPeerId]);

  useEffect(() => {
    if (activePeerId) {
      setLoadingMessages(true);
      fetchActiveMessages(activePeerId).finally(() => setLoadingMessages(false));

      // Poll messages every 3 seconds for instant peer updates
      const interval = setInterval(() => {
        fetchActiveMessages(activePeerId);
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [activePeerId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim() || !activePeerId || sending) return;

    setSending(true);
    setError(null);
    const content = messageInput.trim();

    try {
      const token = localStorage.getItem('sk_token');
      const res = await fetch(`/api/messages/${activePeerId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ content }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to send message.');
      }

      setMessageInput('');
      // Immediately refresh messages and conversations list
      await fetchActiveMessages(activePeerId);
      await fetchConversations();
    } catch (err: any) {
      setError(err.message || 'Failed to send message.');
    } finally {
      setSending(false);
    }
  };

  const activePeer = conversations.find(c => c.peer.id === activePeerId)?.peer;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in">
      
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Messages
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time chat with your study partners and tutors.
          </p>
        </div>
      </div>

      <div className="rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl overflow-hidden grid grid-cols-1 md:grid-cols-3 h-[650px]">
        
        {/* LEFT COLUMN: CONVERSATION LIST */}
        <div className="border-r border-slate-800 flex flex-col h-full bg-slate-950/40">
          <div className="p-4 border-b border-slate-800 flex items-center justify-between">
            <span className="font-bold text-sm text-white">Conversations</span>
            <button
              onClick={() => fetchConversations()}
              className="p-1 rounded text-slate-400 hover:text-white"
              title="Refresh"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {loadingConvos ? (
              <div className="space-y-2 p-2">
                {[1, 2, 3].map(i => (
                  <div key={i} className="h-16 rounded-xl bg-slate-900 animate-pulse" />
                ))}
              </div>
            ) : conversations.length === 0 ? (
              <div className="text-center py-16 px-4">
                <MessageSquare className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                <p className="text-xs text-slate-400">No active conversations yet.</p>
                <p className="text-[11px] text-slate-500 mt-1">
                  Go to Discover Peers to find a tutor and initiate a chat!
                </p>
              </div>
            ) : (
              conversations.map(convo => {
                const isActive = convo.peer.id === activePeerId;
                return (
                  <button
                    key={convo.peer.id}
                    onClick={() => setActivePeerId(convo.peer.id)}
                    className={`w-full text-left p-3 rounded-xl transition flex items-start gap-3 ${
                      isActive
                        ? 'bg-indigo-600/20 border border-indigo-500/40 text-white'
                        : 'hover:bg-slate-900 text-slate-300 border border-transparent'
                    }`}
                  >
                    <img
                      src={convo.peer.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80'}
                      alt={convo.peer.name}
                      className="w-10 h-10 rounded-xl object-cover shrink-0 ring-1 ring-slate-800"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <span className="font-semibold text-xs truncate">{convo.peer.name}</span>
                        <span className="text-[10px] text-slate-500 shrink-0 font-mono">
                          {new Date(convo.lastMessage.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 truncate mt-0.5">
                        {convo.lastMessage.content}
                      </p>
                    </div>
                    {convo.unreadCount > 0 && (
                      <span className="px-1.5 py-0.5 rounded-full text-[10px] font-bold bg-cyan-400 text-slate-950 shrink-0">
                        {convo.unreadCount}
                      </span>
                    )}
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: ACTIVE CHAT THREAD */}
        <div className="md:col-span-2 flex flex-col h-full bg-slate-950">
          {activePeerId ? (
            <>
              {/* Chat Header */}
              <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/60">
                <div className="flex items-center gap-3">
                  <img
                    src={activePeer?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80'}
                    alt={activePeer?.name || 'Peer'}
                    className="w-9 h-9 rounded-xl object-cover ring-1 ring-slate-800"
                  />
                  <div>
                    <h3 className="font-bold text-sm text-white">{activePeer?.name || 'Peer Tutor'}</h3>
                    <p className="text-[10px] text-slate-400">{activePeer?.major || 'Student'}</p>
                  </div>
                </div>
              </div>

              {/* Error banner */}
              {error && (
                <div className="p-2.5 mx-4 mt-2 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {/* Messages Body */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {loadingMessages ? (
                  <div className="text-center py-12 text-xs text-slate-500">Loading conversation...</div>
                ) : messages.length === 0 ? (
                  <div className="text-center py-16 text-xs text-slate-500">
                    No messages in this conversation yet. Send a greeting to start swapping skills!
                  </div>
                ) : (
                  messages.map(msg => {
                    const isMe = msg.senderId === user?.id;
                    return (
                      <div
                        key={msg.id}
                        className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                      >
                        <div
                          className={`max-w-[75%] px-4 py-2.5 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                            isMe
                              ? 'bg-indigo-600 text-white rounded-br-sm shadow-md shadow-indigo-600/20'
                              : 'bg-slate-800 text-slate-200 rounded-bl-sm border border-slate-700/60'
                          }`}
                        >
                          {msg.content}
                        </div>
                        <span className="text-[10px] text-slate-500 mt-1 px-1 font-mono">
                          {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    );
                  })
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Message Input Form */}
              <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-800 flex items-center gap-2 bg-slate-900/60">
                <input
                  type="text"
                  value={messageInput}
                  onChange={e => setMessageInput(e.target.value)}
                  placeholder="Type a message or proposed meeting time..."
                  className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                />
                <button
                  type="submit"
                  disabled={!messageInput.trim() || sending}
                  className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/20 transition disabled:opacity-50"
                  aria-label="Send message"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-slate-500">
              <MessageSquare className="w-12 h-12 text-slate-700 mb-3" />
              <p className="text-sm font-semibold text-slate-400">Select a conversation to start messaging</p>
              <p className="text-xs text-slate-500 mt-1">
                Choose a peer on the left or discover new tutors from the Discover page.
              </p>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
