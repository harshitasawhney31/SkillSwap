import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Booking } from '../types';
import { ReviewModal } from '../components/ReviewModal';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  Check, 
  X, 
  Video, 
  AlertCircle, 
  CheckCircle2, 
  Star, 
  UserCheck, 
  ArrowRight,
  ShieldAlert
} from 'lucide-react';

export function BookingsPage() {
  const { user } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'pending' | 'upcoming' | 'completed' | 'cancelled'>('pending');
  const [selectedBookingForReview, setSelectedBookingForReview] = useState<Booking | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  const fetchBookings = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('sk_token');
      const res = await fetch('/api/bookings', {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (res.ok) {
        const data = await res.json();
        setBookings(data.bookings || []);
      }
    } catch (err) {
      console.error('Failed to load bookings:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBookings();
  }, []);

  const showNotification = (type: 'success' | 'error', message: string) => {
    if (type === 'success') {
      setActionSuccess(message);
      setActionError(null);
    } else {
      setActionError(message);
      setActionSuccess(null);
    }
    setTimeout(() => {
      setActionSuccess(null);
      setActionError(null);
    }, 4000);
  };

  const handleUpdateStatus = async (bookingId: string, status: string) => {
    try {
      const token = localStorage.getItem('sk_token');
      const res = await fetch(`/api/bookings/${bookingId}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to update status.');
      }

      showNotification('success', data.message || `Session marked as ${status.toLowerCase()}.`);
      await fetchBookings();
    } catch (err: any) {
      showNotification('error', err.message || 'Operation failed.');
    }
  };

  // Groupings based on status
  const pendingRequests = bookings.filter(b => b.status === 'PENDING');
  const incomingPending = pendingRequests.filter(b => b.recipientId === user?.id);
  const outgoingPending = pendingRequests.filter(b => b.requesterId === user?.id);

  const upcomingSessions = bookings.filter(b => b.status === 'ACCEPTED');
  const completedSessions = bookings.filter(b => b.status === 'COMPLETED');
  const cancelledSessions = bookings.filter(b => b.status === 'CANCELLED' || b.status === 'REJECTED');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Sessions & Schedule
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Manage your peer swap appointments, incoming requests, and confirmed tutoring slots.
          </p>
        </div>
      </div>

      {/* Notifications */}
      {actionSuccess && (
        <div className="mb-6 p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs flex items-center gap-2.5">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {actionError && (
        <div className="mb-6 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center gap-2.5">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{actionError}</span>
        </div>
      )}

      {/* Category Tabs */}
      <div className="flex p-1 bg-slate-900 border border-slate-800 rounded-2xl mb-8 overflow-x-auto">
        <button
          onClick={() => setActiveTab('pending')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-2 ${
            activeTab === 'pending'
              ? 'bg-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>Pending Requests</span>
          {pendingRequests.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-indigo-950 text-indigo-300 font-bold border border-indigo-700">
              {pendingRequests.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('upcoming')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-2 ${
            activeTab === 'upcoming'
              ? 'bg-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>Upcoming Sessions</span>
          {upcomingSessions.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-emerald-950 text-emerald-300 font-bold border border-emerald-700">
              {upcomingSessions.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('completed')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-2 ${
            activeTab === 'completed'
              ? 'bg-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>Completed ({completedSessions.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('cancelled')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-2 ${
            activeTab === 'cancelled'
              ? 'bg-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>Cancelled ({cancelledSessions.length})</span>
        </button>
      </div>

      {/* CONTENT SECTIONS */}
      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-28 rounded-2xl bg-slate-900 animate-pulse border border-slate-800" />
          ))}
        </div>
      ) : activeTab === 'pending' ? (
        <div className="space-y-8">
          
          {/* Incoming requests (Requires action) */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                Action Required: Incoming Requests ({incomingPending.length})
              </h2>
            </div>

            {incomingPending.length === 0 ? (
              <p className="text-xs text-slate-500 py-4 px-5 rounded-xl bg-slate-900/40 border border-slate-800">
                No pending requests awaiting your response right now.
              </p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {incomingPending.map(booking => (
                  <div
                    key={booking.id}
                    className="p-5 rounded-2xl bg-slate-900 border border-indigo-500/30 ring-1 ring-indigo-500/20 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={booking.requester?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80'}
                            alt={booking.requester?.name || 'Requester'}
                            className="w-10 h-10 rounded-xl object-cover ring-2 ring-slate-800"
                          />
                          <div>
                            <h4 className="font-bold text-sm text-white">{booking.requester?.name}</h4>
                            <p className="text-[11px] text-slate-400">{booking.requester?.major}</p>
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20">
                          Awaiting You
                        </span>
                      </div>

                      <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 mb-3 space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Skill requested:</span>
                          <span className="font-semibold text-indigo-300">{booking.skillName}</span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Date & Time:</span>
                          <span className="font-mono text-slate-200">
                            {booking.proposedDate} • {booking.startTime} - {booking.endTime}
                          </span>
                        </div>
                        {booking.topic && (
                          <div className="text-xs text-slate-300 pt-1 border-t border-slate-800/60">
                            <strong className="text-slate-400">Topic:</strong> {booking.topic}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-2">
                      <button
                        onClick={() => handleUpdateStatus(booking.id, 'ACCEPTED')}
                        className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs shadow-md shadow-emerald-600/20 transition flex items-center justify-center gap-1.5"
                      >
                        <Check className="w-3.5 h-3.5" />
                        Accept Session
                      </button>
                      <button
                        onClick={() => handleUpdateStatus(booking.id, 'REJECTED')}
                        className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-rose-500/20 text-rose-300 font-semibold text-xs transition flex items-center justify-center gap-1.5"
                      >
                        <X className="w-3.5 h-3.5" />
                        Decline
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Outgoing requests */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                Sent by You: Awaiting Peer Response ({outgoingPending.length})
              </h2>
            </div>

            {outgoingPending.length === 0 ? (
              <p className="text-xs text-slate-500 py-4 px-5 rounded-xl bg-slate-900/40 border border-slate-800">
                You have not sent any pending session requests.
              </p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {outgoingPending.map(booking => (
                  <div
                    key={booking.id}
                    className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={booking.recipient?.avatarUrl || 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=80'}
                            alt={booking.recipient?.name || 'Recipient'}
                            className="w-10 h-10 rounded-xl object-cover ring-2 ring-slate-800"
                          />
                          <div>
                            <h4 className="font-bold text-sm text-white">Sent to {booking.recipient?.name}</h4>
                            <p className="text-[11px] text-slate-400">{booking.recipient?.major}</p>
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-400 border border-slate-700">
                          Pending
                        </span>
                      </div>

                      <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 mb-3 space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Skill requested:</span>
                          <span className="font-semibold text-indigo-300">{booking.skillName}</span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Date & Time:</span>
                          <span className="font-mono text-slate-200">
                            {booking.proposedDate} • {booking.startTime} - {booking.endTime}
                          </span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => handleUpdateStatus(booking.id, 'CANCELLED')}
                      className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-rose-500/20 text-rose-400 font-semibold text-xs transition"
                    >
                      Cancel Request
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      ) : activeTab === 'upcoming' ? (
        <div>
          {upcomingSessions.length === 0 ? (
            <div className="text-center py-16 px-4 rounded-3xl bg-slate-900/40 border border-slate-800">
              <CalendarIcon className="w-10 h-10 text-slate-600 mx-auto mb-3" />
              <h3 className="text-base font-bold text-white">No Upcoming Confirmed Sessions</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
                Accepted session requests will appear here with scheduled times and video meeting links.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {upcomingSessions.map(booking => {
                const partner = booking.userRole === 'REQUESTER' ? booking.recipient : booking.requester;
                return (
                  <div
                    key={booking.id}
                    className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-indigo-500/30 transition flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={partner?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80'}
                            alt={partner?.name}
                            className="w-11 h-11 rounded-xl object-cover ring-2 ring-emerald-500/30"
                          />
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="font-bold text-sm text-white">{partner?.name}</h4>
                              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                                Confirmed
                              </span>
                            </div>
                            <p className="text-xs text-slate-400">{partner?.major} • {partner?.university}</p>
                          </div>
                        </div>
                      </div>

                      <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 mb-4 space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Subject:</span>
                          <span className="font-bold text-indigo-300">{booking.skillName}</span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-400">Schedule:</span>
                          <span className="font-mono text-white font-medium">
                            {booking.proposedDate} • {booking.startTime} - {booking.endTime}
                          </span>
                        </div>
                        {booking.topic && (
                          <div className="text-xs text-slate-300 pt-1 border-t border-slate-800/60">
                            <strong className="text-slate-400">Topic:</strong> {booking.topic}
                          </div>
                        )}
                        {booking.meetingUrl && (
                          <div className="pt-2 flex items-center justify-between border-t border-slate-800/60">
                            <span className="text-xs text-slate-400">Meeting Room:</span>
                            <a
                              href={booking.meetingUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-indigo-600/20 text-indigo-300 hover:bg-indigo-600/30 text-xs font-semibold"
                            >
                              <Video className="w-3.5 h-3.5" />
                              Join Meeting
                            </a>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-2 border-t border-slate-800/60">
                      <button
                        onClick={() => handleUpdateStatus(booking.id, 'COMPLETED')}
                        className="flex-1 py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/20 transition flex items-center justify-center gap-1.5"
                      >
                        <UserCheck className="w-3.5 h-3.5" />
                        Mark as Completed
                      </button>
                      <button
                        onClick={() => handleUpdateStatus(booking.id, 'CANCELLED')}
                        className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-rose-500/20 text-rose-300 font-semibold text-xs transition"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : activeTab === 'completed' ? (
        <div>
          {completedSessions.length === 0 ? (
            <div className="text-center py-16 px-4 rounded-3xl bg-slate-900/40 border border-slate-800">
              <UserCheck className="w-10 h-10 text-slate-600 mx-auto mb-3" />
              <h3 className="text-base font-bold text-white">No Completed Sessions Yet</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto mt-1">
                Completed peer exchanges will be listed here. You can rate and review your peer tutor after each session.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {completedSessions.map(booking => {
                const partner = booking.userRole === 'REQUESTER' ? booking.recipient : booking.requester;
                return (
                  <div
                    key={booking.id}
                    className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-3 mb-3">
                        <div className="flex items-center gap-3">
                          <img
                            src={partner?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80'}
                            alt={partner?.name}
                            className="w-10 h-10 rounded-xl object-cover ring-2 ring-slate-800"
                          />
                          <div>
                            <h4 className="font-bold text-sm text-white">{partner?.name}</h4>
                            <p className="text-xs text-slate-400">{partner?.major}</p>
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                          Completed
                        </span>
                      </div>

                      <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 mb-3 text-xs space-y-1">
                        <div><strong className="text-slate-400">Skill:</strong> {booking.skillName}</div>
                        <div><strong className="text-slate-400">Date:</strong> {booking.proposedDate} ({booking.startTime} - {booking.endTime})</div>
                        {booking.topic && <div><strong className="text-slate-400">Topic:</strong> {booking.topic}</div>}
                      </div>
                    </div>

                    <div>
                      {booking.hasReviewed ? (
                        <div className="py-2 px-3 rounded-xl bg-slate-950 border border-slate-800 text-center text-xs text-slate-400 font-semibold flex items-center justify-center gap-1.5">
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Review Submitted</span>
                        </div>
                      ) : (
                        <button
                          onClick={() => setSelectedBookingForReview(booking)}
                          className="w-full py-2 px-3 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 font-semibold text-xs transition flex items-center justify-center gap-1.5"
                        >
                          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                          Leave Verified Review
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        /* CANCELLED SESSIONS */
        <div>
          {cancelledSessions.length === 0 ? (
            <p className="text-xs text-slate-500 text-center py-12">No cancelled sessions.</p>
          ) : (
            <div className="space-y-3">
              {cancelledSessions.map(b => (
                <div key={b.id} className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-xs flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-white">{b.skillName}</span>
                    <span className="text-slate-500 ml-2 font-mono">{b.proposedDate}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/10 text-rose-400 border border-rose-500/20">
                    {b.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Review Modal */}
      {selectedBookingForReview && (
        <ReviewModal
          booking={selectedBookingForReview}
          isOpen={Boolean(selectedBookingForReview)}
          onClose={() => setSelectedBookingForReview(null)}
          onSuccess={() => {
            fetchBookings();
          }}
        />
      )}

    </div>
  );
}
