import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Skill, LearningGoal, Proficiency, Priority } from '../types';
import { 
  Sparkles, 
  Layers, 
  Plus, 
  Trash2, 
  Edit3, 
  ArrowLeftRight, 
  X, 
  AlertCircle, 
  CheckCircle2,
  BookOpen
} from 'lucide-react';

export function SkillsPage() {
  const { refreshUser } = useAuth();
  const [skills, setSkills] = useState<Skill[]>([]);
  const [goals, setGoals] = useState<LearningGoal[]>([]);
  const [loading, setLoading] = useState(true);

  // Modal states
  const [showSkillModal, setShowSkillModal] = useState(false);
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [editingSkill, setEditingSkill] = useState<Skill | null>(null);
  const [editingGoal, setEditingGoal] = useState<LearningGoal | null>(null);

  // Skill Form
  const [skillName, setSkillName] = useState('');
  const [skillCategory, setSkillCategory] = useState('Computer Science');
  const [skillProficiency, setSkillProficiency] = useState<Proficiency>('INTERMEDIATE');
  const [skillDescription, setSkillDescription] = useState('');

  // Goal Form
  const [goalName, setGoalName] = useState('');
  const [goalCategory, setGoalCategory] = useState('Computer Science');
  const [goalDesiredLevel, setGoalDesiredLevel] = useState<Proficiency>('INTERMEDIATE');
  const [goalPriority, setGoalPriority] = useState<Priority>('HIGH');
  const [goalNotes, setGoalNotes] = useState('');

  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const categories = [
    'Computer Science',
    'Mathematics',
    'Design & Frontend',
    'Languages',
    'Business & Economics',
    'Engineering',
    'Sciences',
  ];

  const fetchSkillsAndGoals = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('sk_token');
      const [skillsRes, goalsRes] = await Promise.all([
        fetch('/api/skills', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/goals', { headers: { Authorization: `Bearer ${token}` } }),
      ]);

      if (skillsRes.ok && goalsRes.ok) {
        const skillsData = await skillsRes.json();
        const goalsData = await goalsRes.json();
        setSkills(skillsData.skills || []);
        setGoals(goalsData.goals || []);
      }
    } catch (err) {
      console.error('Failed to fetch skills/goals:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSkillsAndGoals();
  }, []);

  const showToast = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 3500);
  };

  // ---------------------------------------------------------
  // TEACHING SKILLS HANDLERS
  // ---------------------------------------------------------

  const openSkillModal = (skill?: Skill) => {
    if (skill) {
      setEditingSkill(skill);
      setSkillName(skill.name);
      setSkillCategory(skill.category);
      setSkillProficiency(skill.proficiency);
      setSkillDescription(skill.description);
    } else {
      setEditingSkill(null);
      setSkillName('');
      setSkillCategory('Computer Science');
      setSkillProficiency('INTERMEDIATE');
      setSkillDescription('');
    }
    setShowSkillModal(true);
  };

  const handleSaveSkill = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = localStorage.getItem('sk_token');

    try {
      if (editingSkill) {
        const res = await fetch(`/api/skills/${editingSkill.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            name: skillName,
            category: skillCategory,
            proficiency: skillProficiency,
            description: skillDescription,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error);
        showToast('success', `Updated teaching skill "${data.skill.name}".`);
      } else {
        const res = await fetch('/api/skills', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            name: skillName,
            category: skillCategory,
            proficiency: skillProficiency,
            description: skillDescription,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error);
        showToast('success', `Added teaching skill "${data.skill.name}".`);
      }

      setShowSkillModal(false);
      await fetchSkillsAndGoals();
      await refreshUser();
    } catch (err: any) {
      showToast('error', err.message || 'Failed to save skill.');
    }
  };

  const handleDeleteSkill = async (skillId: string, skillName: string) => {
    if (!confirm(`Are you sure you want to remove "${skillName}" from your teaching skills?`)) return;

    const token = localStorage.getItem('sk_token');
    try {
      const res = await fetch(`/api/skills/${skillId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      showToast('success', `Removed "${skillName}". Match recommendations recalculated.`);
      await fetchSkillsAndGoals();
      await refreshUser();
    } catch (err: any) {
      showToast('error', err.message || 'Failed to delete skill.');
    }
  };

  const handleConvertSkillToGoal = async (skill: Skill) => {
    const token = localStorage.getItem('sk_token');
    try {
      const res = await fetch(`/api/skills/${skill.id}/convert-to-goal`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          desiredLevel: 'ADVANCED',
          priority: 'HIGH',
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      showToast('success', `Transformed "${skill.name}" into a Learning Goal!`);
      await fetchSkillsAndGoals();
      await refreshUser();
    } catch (err: any) {
      showToast('error', err.message || 'Failed to convert skill.');
    }
  };

  // ---------------------------------------------------------
  // LEARNING GOALS HANDLERS
  // ---------------------------------------------------------

  const openGoalModal = (goal?: LearningGoal) => {
    if (goal) {
      setEditingGoal(goal);
      setGoalName(goal.name);
      setGoalCategory(goal.category);
      setGoalDesiredLevel(goal.desiredLevel);
      setGoalPriority(goal.priority);
      setGoalNotes(goal.notes);
    } else {
      setEditingGoal(null);
      setGoalName('');
      setGoalCategory('Computer Science');
      setGoalDesiredLevel('INTERMEDIATE');
      setGoalPriority('HIGH');
      setGoalNotes('');
    }
    setShowGoalModal(true);
  };

  const handleSaveGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    const token = localStorage.getItem('sk_token');

    try {
      if (editingGoal) {
        const res = await fetch(`/api/goals/${editingGoal.id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            name: goalName,
            category: goalCategory,
            desiredLevel: goalDesiredLevel,
            priority: goalPriority,
            notes: goalNotes,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error);
        showToast('success', `Updated learning goal "${data.goal.name}".`);
      } else {
        const res = await fetch('/api/goals', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            name: goalName,
            category: goalCategory,
            desiredLevel: goalDesiredLevel,
            priority: goalPriority,
            notes: goalNotes,
          }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error);
        showToast('success', `Added learning goal "${data.goal.name}".`);
      }

      setShowGoalModal(false);
      await fetchSkillsAndGoals();
      await refreshUser();
    } catch (err: any) {
      showToast('error', err.message || 'Failed to save learning goal.');
    }
  };

  const handleDeleteGoal = async (goalId: string, goalName: string) => {
    if (!confirm(`Are you sure you want to remove learning goal "${goalName}"?`)) return;

    const token = localStorage.getItem('sk_token');
    try {
      const res = await fetch(`/api/goals/${goalId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      showToast('success', `Removed goal "${goalName}".`);
      await fetchSkillsAndGoals();
      await refreshUser();
    } catch (err: any) {
      showToast('error', err.message || 'Failed to delete goal.');
    }
  };

  const handleConvertGoalToSkill = async (goal: LearningGoal) => {
    const token = localStorage.getItem('sk_token');
    try {
      const res = await fetch(`/api/goals/${goal.id}/convert-to-skill`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          proficiency: goal.desiredLevel,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      showToast('success', `Shifted "${goal.name}" from Goal to Teaching Skill!`);
      await fetchSkillsAndGoals();
      await refreshUser();
    } catch (err: any) {
      showToast('error', err.message || 'Failed to convert goal.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in">
      
      {/* Toast Notification */}
      {notification && (
        <div
          className={`fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-xl text-xs font-semibold border animate-in slide-in-from-bottom-2 ${
            notification.type === 'success'
              ? 'bg-emerald-950/90 text-emerald-200 border-emerald-500/30'
              : 'bg-rose-950/90 text-rose-200 border-rose-500/30'
          }`}
        >
          {notification.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          )}
          <span>{notification.message}</span>
        </div>
      )}

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Manage Skills & Learning Goals
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Keep your strengths and aspirations updated. The matching algorithm re-evaluates student compatibility every time you make a change.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* LEFT COLUMN: TEACHING SKILLS */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center border border-indigo-500/20">
                  <Layers className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-bold text-base text-white">Skills You Can Teach</h2>
                  <p className="text-[11px] text-slate-400">Share your expertise and tutor peers</p>
                </div>
              </div>
              <button
                onClick={() => openSkillModal()}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md shadow-indigo-600/20 transition"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Skill
              </button>
            </div>

            {loading ? (
              <div className="space-y-3">
                {[1, 2].map(i => (
                  <div key={i} className="h-20 rounded-xl bg-slate-950/60 animate-pulse" />
                ))}
              </div>
            ) : skills.length === 0 ? (
              <div className="text-center py-12 px-4 rounded-xl bg-slate-950/40 border border-dashed border-slate-800">
                <BookOpen className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                <h4 className="text-sm font-semibold text-slate-300">No teaching skills added yet</h4>
                <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                  Add subjects or coding languages you feel comfortable helping others with.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {skills.map(skill => (
                  <div
                    key={skill.id}
                    className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-bold text-sm text-white">{skill.name}</h3>
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                            {skill.proficiency}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-400 font-mono">{skill.category}</span>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleConvertSkillToGoal(skill)}
                          title="Convert to Learning Goal"
                          className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-800 transition"
                        >
                          <ArrowLeftRight className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => openSkillModal(skill)}
                          title="Edit Skill"
                          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteSkill(skill.id, skill.name)}
                          title="Delete Skill"
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {skill.description && (
                      <p className="text-xs text-slate-300 mt-2 leading-relaxed">{skill.description}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: LEARNING GOALS */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center border border-cyan-500/20">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-bold text-base text-white">Your Learning Goals</h2>
                  <p className="text-[11px] text-slate-400">Skills you want to master with a peer tutor</p>
                </div>
              </div>
              <button
                onClick={() => openGoalModal()}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-md shadow-cyan-600/20 transition"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Goal
              </button>
            </div>

            {loading ? (
              <div className="space-y-3">
                {[1, 2].map(i => (
                  <div key={i} className="h-20 rounded-xl bg-slate-950/60 animate-pulse" />
                ))}
              </div>
            ) : goals.length === 0 ? (
              <div className="text-center py-12 px-4 rounded-xl bg-slate-950/40 border border-dashed border-slate-800">
                <Sparkles className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                <h4 className="text-sm font-semibold text-slate-300">No learning goals added yet</h4>
                <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                  Add topics you are currently studying or struggling with to get matched.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {goals.map(goal => (
                  <div
                    key={goal.id}
                    className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-bold text-sm text-white">{goal.name}</h3>
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-semibold border ${
                            goal.priority === 'HIGH'
                              ? 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                              : 'bg-slate-800 text-slate-400 border-slate-700'
                          }`}>
                            {goal.priority} Priority
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                          <span className="font-mono">{goal.category}</span>
                          <span>•</span>
                          <span>Target: <strong className="text-cyan-300 font-semibold">{goal.desiredLevel}</strong></span>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleConvertGoalToSkill(goal)}
                          title="Convert to Teaching Skill"
                          className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-400 hover:bg-slate-800 transition"
                        >
                          <ArrowLeftRight className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => openGoalModal(goal)}
                          title="Edit Goal"
                          className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteGoal(goal.id, goal.name)}
                          title="Delete Goal"
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {goal.notes && (
                      <p className="text-xs text-slate-300 mt-2 leading-relaxed">{goal.notes}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

      </div>

      {/* MODAL: ADD / EDIT TEACHING SKILL */}
      {showSkillModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-2xl">
            <button
              onClick={() => setShowSkillModal(false)}
              className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="font-bold text-lg text-white mb-1">
              {editingSkill ? 'Edit Teaching Skill' : 'Add Teaching Skill'}
            </h3>
            <p className="text-xs text-slate-400 mb-5">
              Specify what you can teach and your proficiency level.
            </p>

            <form onSubmit={handleSaveSkill} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Skill or Subject Name</label>
                <input
                  type="text"
                  required
                  value={skillName}
                  onChange={e => setSkillName(e.target.value)}
                  placeholder="e.g. C++, React, Linear Algebra, Figma"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Category</label>
                  <select
                    value={skillCategory}
                    onChange={e => setSkillCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-indigo-500"
                  >
                    {categories.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Proficiency</label>
                  <select
                    value={skillProficiency}
                    onChange={e => setSkillProficiency(e.target.value as Proficiency)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="BEGINNER">Beginner</option>
                    <option value="INTERMEDIATE">Intermediate</option>
                    <option value="ADVANCED">Advanced</option>
                    <option value="EXPERT">Expert</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Description & Topics Covered</label>
                <textarea
                  rows={3}
                  value={skillDescription}
                  onChange={e => setSkillDescription(e.target.value)}
                  placeholder="e.g. Pointers, memory allocation, object-oriented principles..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-indigo-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowSkillModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/30 transition"
                >
                  Save Skill
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: ADD / EDIT LEARNING GOAL */}
      {showGoalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 p-6 shadow-2xl">
            <button
              onClick={() => setShowGoalModal(false)}
              className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="font-bold text-lg text-white mb-1">
              {editingGoal ? 'Edit Learning Goal' : 'Add Learning Goal'}
            </h3>
            <p className="text-xs text-slate-400 mb-5">
              Specify what you want to learn and your target proficiency.
            </p>

            <form onSubmit={handleSaveGoal} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Goal or Subject Name</label>
                <input
                  type="text"
                  required
                  value={goalName}
                  onChange={e => setGoalName(e.target.value)}
                  placeholder="e.g. React, C++, Machine Learning, French"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Category</label>
                  <select
                    value={goalCategory}
                    onChange={e => setGoalCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-cyan-500"
                  >
                    {categories.map(c => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">Priority</label>
                  <select
                    value={goalPriority}
                    onChange={e => setGoalPriority(e.target.value as Priority)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-cyan-500"
                  >
                    <option value="HIGH">High Priority</option>
                    <option value="MEDIUM">Medium Priority</option>
                    <option value="LOW">Low Priority</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Target Desired Level</label>
                <select
                  value={goalDesiredLevel}
                  onChange={e => setGoalDesiredLevel(e.target.value as Proficiency)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-cyan-500"
                >
                  <option value="BEGINNER">Beginner (Foundations)</option>
                  <option value="INTERMEDIATE">Intermediate (Coursework)</option>
                  <option value="ADVANCED">Advanced (Projects / Interviews)</option>
                  <option value="EXPERT">Expert (Mastery)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Learning Notes & Deadlines</label>
                <textarea
                  rows={3}
                  value={goalNotes}
                  onChange={e => setGoalNotes(e.target.value)}
                  placeholder="e.g. Preparing for midterm in CS240, want weekly practice sessions..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-cyan-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowGoalModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-800 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs shadow-md shadow-cyan-600/30 transition"
                >
                  Save Goal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
