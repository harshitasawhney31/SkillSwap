import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Availability, Review } from '../types';
import { 
  User as UserIcon, 
  Calendar, 
  Star, 
  Lock, 
  Settings as SettingsIcon, 
  CheckCircle2, 
  AlertCircle, 
  Plus, 
  Trash2, 
  GraduationCap, 
  Building2,
  Clock,
  ShieldAlert
} from 'lucide-react';

export function ProfileSettingsPage() {
  const { user, refreshUser, logout } = useAuth();
  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'availability' | 'reviews' | 'security' | 'preferences'>('profile');

  // Profile Form State
  const [name, setName] = useState(user?.name || '');
  const [university, setUniversity] = useState(user?.university || '');
  const [major, setMajor] = useState(user?.major || '');
  const [graduationYear, setGraduationYear] = useState(user?.graduationYear?.toString() || '2026');
  const [bio, setBio] = useState(user?.bio || '');
  const [avatarUrl, setAvatarUrl] = useState(user?.avatarUrl || '');

  // Availability State
  const [availabilities, setAvailabilities] = useState<Availability[]>([]);
  const [newDay, setNewDay] = useState(1);
  const [newStart, setNewStart] = useState('14:00');
  const [newEnd, setNewEnd] = useState('18:00');

  // Reviews State
  const [reviews, setReviews] = useState<Review[]>([]);

  // Security Form State
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Preferences State
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [sessionReminders, setSessionReminders] = useState(true);
  const [allowMatching, setAllowMatching] = useState(true);
  const [preferredMeeting, setPreferredMeeting] = useState('Virtual');

  // Status feedback
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (user) {
      setName(user.name || '');
      setUniversity(user.university || '');
      setMajor(user.major || '');
      setGraduationYear(user.graduationYear?.toString() || '2026');
      setBio(user.bio || '');
      setAvatarUrl(user.avatarUrl || '');
    }
  }, [user]);

  const showStatus = (type: 'success' | 'error', text: string) => {
    setStatusMessage({ type, text });
    setTimeout(() => setStatusMessage(null), 3500);
  };

  // Fetch Availability, Reviews & Preferences
  const fetchAuxData = async () => {
    const token = localStorage.getItem('sk_token');
    try {
      const [availRes, revRes, prefRes] = await Promise.all([
        fetch('/api/availability', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/reviews', { headers: { Authorization: `Bearer ${token}` } }),
        fetch('/api/preferences', { headers: { Authorization: `Bearer ${token}` } }),
      ]);

      if (availRes.ok) {
        const d = await availRes.json();
        setAvailabilities(d.availabilities || []);
      }
      if (revRes.ok) {
        const d = await revRes.json();
        setReviews(d.reviews || []);
      }
      if (prefRes.ok) {
        const d = await prefRes.json();
        if (d.preferences) {
          setEmailNotifications(Boolean(d.preferences.emailNotifications));
          setSessionReminders(Boolean(d.preferences.sessionReminders));
          setAllowMatching(Boolean(d.preferences.allowMatching));
          setPreferredMeeting(d.preferences.preferredMeeting || 'Virtual');
        }
      }
    } catch (err) {
      console.error('Failed to fetch aux data:', err);
    }
  };

  useEffect(() => {
    fetchAuxData();
  }, []);

  // Update Profile
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const token = localStorage.getItem('sk_token');
      const res = await fetch('/api/auth/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name,
          university,
          major,
          graduationYear: parseInt(graduationYear) || 2026,
          bio,
          avatarUrl,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      showStatus('success', 'Profile details updated and persisted.');
      await refreshUser();
    } catch (err: any) {
      showStatus('error', err.message || 'Failed to update profile.');
    } finally {
      setSaving(false);
    }
  };

  // Add Availability Slot
  const handleAddAvailability = async () => {
    const token = localStorage.getItem('sk_token');
    const updatedSlots = [
      ...availabilities.map(a => ({ dayOfWeek: a.dayOfWeek, startTime: a.startTime, endTime: a.endTime })),
      { dayOfWeek: newDay, startTime: newStart, endTime: newEnd },
    ];

    try {
      const res = await fetch('/api/availability', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ slots: updatedSlots }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setAvailabilities(data.availabilities || []);
      showStatus('success', 'Availability schedule updated.');
      await refreshUser();
    } catch (err: any) {
      showStatus('error', err.message || 'Failed to update availability.');
    }
  };

  // Delete Availability Slot
  const handleDeleteAvailability = async (slotId: string) => {
    const token = localStorage.getItem('sk_token');
    const updatedSlots = availabilities
      .filter(a => a.id !== slotId)
      .map(a => ({ dayOfWeek: a.dayOfWeek, startTime: a.startTime, endTime: a.endTime }));

    try {
      const res = await fetch('/api/availability', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ slots: updatedSlots }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setAvailabilities(data.availabilities || []);
      showStatus('success', 'Availability slot removed.');
      await refreshUser();
    } catch (err: any) {
      showStatus('error', err.message || 'Failed to remove slot.');
    }
  };

  // Change Password
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      showStatus('error', 'New password and confirmation do not match.');
      return;
    }

    setSaving(true);
    try {
      const token = localStorage.getItem('sk_token');
      const res = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ currentPassword, newPassword }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      showStatus('success', 'Password successfully changed and updated in database.');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: any) {
      showStatus('error', err.message || 'Failed to change password.');
    } finally {
      setSaving(false);
    }
  };

  // Update Preferences
  const handleSavePreferences = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const token = localStorage.getItem('sk_token');
      const res = await fetch('/api/preferences', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          emailNotifications,
          sessionReminders,
          allowMatching,
          preferredMeeting,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      showStatus('success', 'Notification and matching preferences saved.');
    } catch (err: any) {
      showStatus('error', err.message || 'Failed to save preferences.');
    } finally {
      setSaving(false);
    }
  };

  // Delete Account Permanently
  const handleDeleteAccount = async () => {
    if (!confirm('CRITICAL ACTION: Are you absolutely certain you want to permanently delete your account? All your skills, sessions, messages, and reviews will be removed from the database.')) {
      return;
    }

    try {
      const token = localStorage.getItem('sk_token');
      const res = await fetch('/api/auth/account', {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        await logout();
      }
    } catch (err) {
      console.error('Failed to delete account:', err);
    }
  };

  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in">
      
      {/* Toast */}
      {statusMessage && (
        <div
          className={`fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-3 rounded-xl shadow-xl text-xs font-semibold border ${
            statusMessage.type === 'success'
              ? 'bg-emerald-950/90 text-emerald-200 border-emerald-500/30'
              : 'bg-rose-950/90 text-rose-200 border-rose-500/30'
          }`}
        >
          {statusMessage.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          )}
          <span>{statusMessage.text}</span>
        </div>
      )}

      {/* Profile Overview Card */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/30 to-slate-900 border border-slate-800 mb-8 flex flex-col sm:flex-row items-center sm:items-start gap-5">
        <img
          src={avatarUrl || user?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
          alt={name}
          className="w-20 h-20 rounded-2xl object-cover ring-2 ring-indigo-500/40 shadow-xl"
        />
        <div className="flex-1 text-center sm:text-left">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h1 className="text-xl sm:text-2xl font-extrabold text-white">{name || user?.name}</h1>
              <p className="text-xs text-slate-400 mt-0.5">{major} • Class of {graduationYear} • {university}</p>
            </div>
            
            {/* Real Rating Badge calculated from DB reviews */}
            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 self-center sm:self-auto">
              <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
              <span className="font-bold text-sm text-white">
                {user?.averageRating && user.averageRating > 0 ? user.averageRating.toFixed(1) : 'New Tutor'}
              </span>
              <span className="text-xs text-slate-500 font-normal">
                ({user?.totalReviews || 0} reviews)
              </span>
            </div>
          </div>

          <p className="text-xs text-slate-300 mt-3 max-w-2xl leading-relaxed">
            {bio || 'No bio provided yet. Add a few sentences to help peers understand your learning goals!'}
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex p-1 bg-slate-900 border border-slate-800 rounded-2xl mb-8 overflow-x-auto">
        <button
          onClick={() => setActiveSubTab('profile')}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-1.5 ${
            activeSubTab === 'profile' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <UserIcon className="w-3.5 h-3.5" />
          Profile Details
        </button>

        <button
          onClick={() => setActiveSubTab('availability')}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-1.5 ${
            activeSubTab === 'availability' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          Availability Schedule
        </button>

        <button
          onClick={() => setActiveSubTab('reviews')}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-1.5 ${
            activeSubTab === 'reviews' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Star className="w-3.5 h-3.5" />
          Reviews Received ({reviews.length})
        </button>

        <button
          onClick={() => setActiveSubTab('security')}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-1.5 ${
            activeSubTab === 'security' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          Security & Password
        </button>

        <button
          onClick={() => setActiveSubTab('preferences')}
          className={`flex-1 min-w-[120px] py-2.5 px-3 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-1.5 ${
            activeSubTab === 'preferences' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <SettingsIcon className="w-3.5 h-3.5" />
          Preferences
        </button>
      </div>

      {/* TAB CONTENT: PROFILE DETAILS */}
      {activeSubTab === 'profile' && (
        <div className="max-w-2xl rounded-2xl bg-slate-900 border border-slate-800 p-6">
          <h2 className="font-bold text-base text-white mb-1">Edit Student Profile</h2>
          <p className="text-xs text-slate-400 mb-6">Changes persist directly to your user account in the database.</p>

          <form onSubmit={handleSaveProfile} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Major</label>
                <input
                  type="text"
                  required
                  value={major}
                  onChange={e => setMajor(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Graduation Year</label>
                <input
                  type="number"
                  required
                  min={2024}
                  max={2032}
                  value={graduationYear}
                  onChange={e => setGraduationYear(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">College or University</label>
              <input
                type="text"
                required
                value={university}
                onChange={e => setUniversity(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Avatar Image URL</label>
              <input
                type="url"
                value={avatarUrl}
                onChange={e => setAvatarUrl(e.target.value)}
                placeholder="https://..."
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Bio</label>
              <textarea
                rows={4}
                value={bio}
                onChange={e => setBio(e.target.value)}
                placeholder="Describe your academic focus, projects, and tutoring philosophy..."
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-indigo-500 resize-none"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={saving}
                className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/30 transition disabled:opacity-50"
              >
                {saving ? 'Saving...' : 'Save Profile Changes'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB CONTENT: AVAILABILITY SCHEDULE */}
      {activeSubTab === 'availability' && (
        <div className="max-w-2xl rounded-2xl bg-slate-900 border border-slate-800 p-6">
          <h2 className="font-bold text-base text-white mb-1">Weekly Free Windows for Peer Sessions</h2>
          <p className="text-xs text-slate-400 mb-6">
            Matching algorithms prioritize peers whose available hours overlap with yours.
          </p>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 mb-6 space-y-3">
            <span className="text-xs font-semibold text-indigo-300">Add New Free Time Window</span>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Day of Week</label>
                <select
                  value={newDay}
                  onChange={e => setNewDay(Number(e.target.value))}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                >
                  {dayNames.map((d, idx) => (
                    <option key={d} value={idx}>{d}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">Start Time</label>
                <input
                  type="time"
                  value={newStart}
                  onChange={e => setNewStart(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">End Time</label>
                <input
                  type="time"
                  value={newEnd}
                  onChange={e => setNewEnd(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                />
              </div>
            </div>

            <button
              type="button"
              onClick={handleAddAvailability}
              className="mt-2 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Time Window
            </button>
          </div>

          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Current Active Windows</h3>
            {availabilities.length === 0 ? (
              <p className="text-xs text-slate-500 italic py-4">No availability slots set. Add your free days above.</p>
            ) : (
              availabilities.map(slot => (
                <div
                  key={slot.id}
                  className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800"
                >
                  <div className="flex items-center gap-3">
                    <Clock className="w-4 h-4 text-indigo-400" />
                    <div>
                      <span className="font-semibold text-xs text-white">{dayNames[slot.dayOfWeek]}</span>
                      <span className="text-xs text-slate-400 font-mono ml-2">
                        {slot.startTime} – {slot.endTime}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => handleDeleteAvailability(slot.id)}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-slate-800"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB CONTENT: REVIEWS */}
      {activeSubTab === 'reviews' && (
        <div className="max-w-3xl rounded-2xl bg-slate-900 border border-slate-800 p-6">
          <div className="flex items-center justify-between mb-6 pb-4 border-b border-slate-800">
            <div>
              <h2 className="font-bold text-base text-white">Peer Feedback & Reviews</h2>
              <p className="text-xs text-slate-400">Ratings calculated from real completed study sessions.</p>
            </div>
            <div className="text-right">
              <div className="flex items-center gap-1 text-amber-400 font-bold text-lg justify-end">
                <Star className="w-5 h-5 fill-amber-400" />
                <span>{user?.averageRating && user.averageRating > 0 ? user.averageRating.toFixed(1) : '5.0'}</span>
              </div>
              <p className="text-[10px] text-slate-500">{reviews.length} ratings received</p>
            </div>
          </div>

          {reviews.length === 0 ? (
            <div className="text-center py-12 px-4 rounded-xl bg-slate-950 border border-slate-800">
              <Star className="w-8 h-8 text-slate-600 mx-auto mb-2" />
              <p className="text-xs text-slate-400 font-medium">No reviews received yet</p>
              <p className="text-[11px] text-slate-500 mt-1">Complete a peer swap session to collect verified student feedback.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {reviews.map(rev => (
                <div key={rev.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-center gap-2.5">
                      <img
                        src={rev.reviewer?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80'}
                        alt={rev.reviewer?.name}
                        className="w-8 h-8 rounded-lg object-cover ring-1 ring-slate-800"
                      />
                      <div>
                        <div className="font-semibold text-xs text-white">{rev.reviewer?.name || 'Fellow Student'}</div>
                        <div className="text-[10px] text-slate-500">{rev.reviewer?.major} • Session: {rev.skillName}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 text-amber-400">
                      {[...Array(rev.rating)].map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                      ))}
                    </div>
                  </div>
                  <p className="text-xs text-slate-300 pl-10 leading-relaxed italic">"{rev.feedback}"</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT: SECURITY & PASSWORD */}
      {activeSubTab === 'security' && (
        <div className="max-w-md rounded-2xl bg-slate-900 border border-slate-800 p-6">
          <h2 className="font-bold text-base text-white mb-1">Change Account Password</h2>
          <p className="text-xs text-slate-400 mb-6">
            Requires verifying your current password before updating the database hash.
          </p>

          <form onSubmit={handleChangePassword} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Current Password</label>
              <input
                type="password"
                required
                value={currentPassword}
                onChange={e => setCurrentPassword(e.target.value)}
                placeholder="Enter current password"
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">New Password (min 6 characters)</label>
              <input
                type="password"
                required
                minLength={6}
                value={newPassword}
                onChange={e => setNewPassword(e.target.value)}
                placeholder="Enter new password"
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">Confirm New Password</label>
              <input
                type="password"
                required
                minLength={6}
                value={confirmPassword}
                onChange={e => setConfirmPassword(e.target.value)}
                placeholder="Re-enter new password"
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <button
              type="submit"
              disabled={saving}
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/30 transition disabled:opacity-50"
            >
              {saving ? 'Updating...' : 'Update Password'}
            </button>
          </form>
        </div>
      )}

      {/* TAB CONTENT: PREFERENCES & DANGER ZONE */}
      {activeSubTab === 'preferences' && (
        <div className="max-w-2xl space-y-8">
          
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-6">
            <h2 className="font-bold text-base text-white mb-1">Notification & Matching Preferences</h2>
            <p className="text-xs text-slate-400 mb-6">Control session reminders and campus matching visibility.</p>

            <form onSubmit={handleSavePreferences} className="space-y-4">
              <label className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer">
                <div>
                  <div className="text-xs font-semibold text-white">Email Session Alerts</div>
                  <div className="text-[11px] text-slate-400">Receive email notifications when peers propose swap sessions</div>
                </div>
                <input
                  type="checkbox"
                  checked={emailNotifications}
                  onChange={e => setEmailNotifications(e.target.checked)}
                  className="w-4 h-4 rounded text-indigo-600 focus:ring-0"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer">
                <div>
                  <div className="text-xs font-semibold text-white">Upcoming Session Reminders</div>
                  <div className="text-[11px] text-slate-400">Send reminder alerts 1 hour before scheduled tutor calls</div>
                </div>
                <input
                  type="checkbox"
                  checked={sessionReminders}
                  onChange={e => setSessionReminders(e.target.checked)}
                  className="w-4 h-4 rounded text-indigo-600 focus:ring-0"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800 cursor-pointer">
                <div>
                  <div className="text-xs font-semibold text-white">Allow Reciprocal Peer Matching</div>
                  <div className="text-[11px] text-slate-400">Include your teaching skills in other students' Discover page results</div>
                </div>
                <input
                  type="checkbox"
                  checked={allowMatching}
                  onChange={e => setAllowMatching(e.target.checked)}
                  className="w-4 h-4 rounded text-indigo-600 focus:ring-0"
                />
              </label>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">Preferred Meeting Location</label>
                <select
                  value={preferredMeeting}
                  onChange={e => setPreferredMeeting(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="Virtual">Virtual (Google Meet / Zoom)</option>
                  <option value="Campus Library">Campus Library Study Room</option>
                  <option value="Student Center">Student Center Lounge</option>
                  <option value="Engineering Lab">Engineering / Computer Science Lab</option>
                </select>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={saving}
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shadow-md shadow-indigo-600/30 transition disabled:opacity-50"
                >
                  {saving ? 'Saving...' : 'Save Preferences'}
                </button>
              </div>
            </form>
          </div>

          {/* DANGER ZONE: ACCOUNT DELETION */}
          <div className="rounded-2xl bg-rose-950/20 border border-rose-500/30 p-6">
            <div className="flex items-center gap-2.5 mb-2">
              <ShieldAlert className="w-5 h-5 text-rose-400" />
              <h3 className="font-bold text-sm text-rose-300">Danger Zone: Delete Account</h3>
            </div>
            <p className="text-xs text-slate-400 mb-4 leading-relaxed">
              Permanently delete your student profile, teaching skills, learning goals, scheduled sessions, reviews, and messaging history. This cannot be undone.
            </p>
            <button
              type="button"
              onClick={handleDeleteAccount}
              className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs shadow-md shadow-rose-600/20 transition"
            >
              Permanently Delete Account
            </button>
          </div>

        </div>
      )}

    </div>
  );
}
