export type Proficiency = 'BEGINNER' | 'INTERMEDIATE' | 'ADVANCED' | 'EXPERT';
export type Priority = 'LOW' | 'MEDIUM' | 'HIGH';
export type BookingStatus = 'PENDING' | 'ACCEPTED' | 'REJECTED' | 'CANCELLED' | 'COMPLETED';

export interface User {
  id: string;
  email: string;
  name: string;
  university: string;
  major: string;
  graduationYear: number;
  bio: string;
  avatarUrl: string;
  role: 'STUDENT' | 'ADMIN';
  averageRating: number;
  totalReviews: number;
  createdAt: string;
  updatedAt: string;
  teachingSkills?: Skill[];
  learningGoals?: LearningGoal[];
  availabilities?: Availability[];
  preferences?: UserPreference;
  reviewsReceived?: Review[];
}

export interface Skill {
  id: string;
  userId: string;
  name: string;
  category: string;
  proficiency: Proficiency;
  description: string;
  createdAt: string;
}

export interface LearningGoal {
  id: string;
  userId: string;
  name: string;
  category: string;
  desiredLevel: Proficiency;
  priority: Priority;
  notes: string;
  createdAt: string;
}

export interface Availability {
  id: string;
  userId: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
  createdAt: string;
}

export interface Booking {
  id: string;
  requesterId: string;
  recipientId: string;
  skillName: string;
  topic: string;
  proposedDate: string;
  startTime: string;
  endTime: string;
  status: BookingStatus;
  notes: string;
  meetingUrl: string;
  createdAt: string;
  updatedAt: string;
  requester?: {
    id: string;
    name: string;
    email: string;
    avatarUrl: string;
    major: string;
    university?: string;
  } | null;
  recipient?: {
    id: string;
    name: string;
    email: string;
    avatarUrl: string;
    major: string;
    university?: string;
  } | null;
  userRole?: 'REQUESTER' | 'RECIPIENT';
  hasReviewed?: boolean;
}

export interface Message {
  id: string;
  senderId: string;
  recipientId: string;
  content: string;
  read: boolean;
  createdAt: string;
}

export interface ConversationItem {
  peer: {
    id: string;
    name: string;
    email: string;
    avatarUrl: string;
    major: string;
  };
  lastMessage: Message;
  unreadCount: number;
}

export interface Review {
  id: string;
  bookingId: string;
  reviewerId: string;
  revieweeId: string;
  rating: number;
  feedback: string;
  createdAt: string;
  reviewer?: {
    id: string;
    name: string;
    avatarUrl: string;
    major: string;
  };
  skillName?: string;
}

export interface Notification {
  id: string;
  userId: string;
  type: string;
  title: string;
  message: string;
  link: string;
  read: boolean;
  createdAt: string;
}

export interface UserPreference {
  id: string;
  userId: string;
  emailNotifications: boolean;
  sessionReminders: boolean;
  allowMatching: boolean;
  preferredMeeting: string;
}

export interface PeerProfile extends User {
  matchScore: number;
  matchReasons: string[];
  isReciprocal: boolean;
  matchedTheyTeach: string[];
  matchedYouTeach: string[];
}
