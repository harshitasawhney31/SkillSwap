/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { AuthModal } from './components/AuthModal';
import { DiscoverPage } from './pages/DiscoverPage';
import { SkillsPage } from './pages/SkillsPage';
import { BookingsPage } from './pages/BookingsPage';
import { MessagesPage } from './pages/MessagesPage';
import { ProfileSettingsPage } from './pages/ProfileSettingsPage';
import { 
  Sparkles, 
  ArrowLeftRight, 
  BookOpen, 
  Calendar, 
  CheckCircle2, 
  Users, 
  Star,
  ShieldCheck
} from 'lucide-react';

function MainContent() {
  const { user, loading, switchTestStudent } = useAuth();
  const [activeTab, setActiveTab] = useState('discover');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authDefaultMode, setAuthDefaultMode] = useState<'login' | 'register'>('login');
  const [activeMessagePeerId, setActiveMessagePeerId] = useState<string | null>(null);

  const handleOpenChat = (peerId: string) => {
    setActiveMessagePeerId(peerId);
    setActiveTab('messages');
  };

  const handleOpenAuth = (mode: 'login' | 'register' = 'login') => {
    setAuthDefaultMode(mode);
    setShowAuthModal(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600 animate-spin flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <span className="text-xs text-slate-400 font-mono">Initializing SkillSwap...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAuth={() => handleOpenAuth('login')}
      />

      <main className="flex-1">
        {!user ? (
          /* Public Unauthenticated Welcome / Hero with Quick Testing Shortcuts */
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold mb-6">
                <Sparkles className="w-3.5 h-3.5" />
                Live Full-Stack Peer Tutoring Network
              </div>
              
              <h1 className="text-4xl sm:text-6xl font-extrabold text-white tracking-tight leading-tight">
                Exchange skills, find peer tutors, and master coursework.
              </h1>
              
              <p className="text-base sm:text-lg text-slate-400 mt-6 leading-relaxed max-w-2xl mx-auto">
                No subscription fees or fake profiles. Real college students exchanging real academic expertise: teach what you excel at, learn what you find challenging.
              </p>

              <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
                <button
                  onClick={() => handleOpenAuth('register')}
                  className="w-full sm:w-auto px-7 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 transition transform hover:-translate-y-0.5"
                >
                  Create Student Account
                </button>
                <button
                  onClick={() => handleOpenAuth('login')}
                  className="w-full sm:w-auto px-7 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 font-bold text-sm transition"
                >
                  Sign In to Account
                </button>
              </div>

              {/* Instant Test Student Switcher for Quick Evaluation */}
              <div className="mt-12 p-6 rounded-2xl bg-slate-900/60 border border-slate-800 text-left max-w-xl mx-auto">
                <div className="flex items-center gap-2 text-xs font-bold text-indigo-300 uppercase tracking-wider mb-2">
                  <Users className="w-4 h-4 text-indigo-400" />
                  Instant Test-Student Logins (Dual Account Workflows A - E)
                </div>
                <p className="text-xs text-slate-400 mb-4">
                  Click any verified student below to test real reciprocal matching, booking requests, and messaging:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    onClick={() => switchTestStudent('alex.rivera@university.edu')}
                    className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-indigo-500/50 hover:bg-indigo-950/20 text-left transition"
                  >
                    <div className="text-xs font-bold text-white">Alex Rivera (Student A)</div>
                    <div className="text-[11px] text-slate-400">Teaches C++ • Wants React</div>
                  </button>
                  <button
                    onClick={() => switchTestStudent('priya.patel@university.edu')}
                    className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-indigo-500/50 hover:bg-indigo-950/20 text-left transition"
                  >
                    <div className="text-xs font-bold text-white">Priya Patel (Student B)</div>
                    <div className="text-[11px] text-slate-400">Teaches React • Wants C++</div>
                  </button>
                  <button
                    onClick={() => switchTestStudent('jordan.lee@university.edu')}
                    className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-indigo-500/50 hover:bg-indigo-950/20 text-left transition"
                  >
                    <div className="text-xs font-bold text-white">Jordan Lee</div>
                    <div className="text-[11px] text-slate-400">Teaches Math • Wants Python</div>
                  </button>
                  <button
                    onClick={() => switchTestStudent('marcus.chen@university.edu')}
                    className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-indigo-500/50 hover:bg-indigo-950/20 text-left transition"
                  >
                    <div className="text-xs font-bold text-white">Marcus Chen</div>
                    <div className="text-[11px] text-slate-400">Teaches Figma • Wants Math</div>
                  </button>
                </div>
              </div>
            </div>

            {/* Feature Highlights Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-12 border-t border-slate-800/80">
              <div className="p-6 rounded-2xl bg-slate-900/40 border border-slate-800">
                <div className="w-10 h-10 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center mb-4">
                  <ArrowLeftRight className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-base text-white">Reciprocal Match Algorithm</h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  Identifies 2-way swaps where peer A teaches what peer B wants to learn, and peer B teaches what peer A wants to learn.
                </p>
              </div>

              <div className="p-6 rounded-2xl bg-slate-900/40 border border-slate-800">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center mb-4">
                  <Calendar className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-base text-white">Conflict-Free Bookings</h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  Real calendar state machine with concurrency-safe collision rejection for overlapping accepted sessions.
                </p>
              </div>

              <div className="p-6 rounded-2xl bg-slate-900/40 border border-slate-800">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-4">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-base text-white">Verified Peer Reviews</h3>
                <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                  Only participants who complete verified tutoring sessions can review, dynamically calculating tutor ratings.
                </p>
              </div>
            </div>
          </div>
        ) : (
          /* Authenticated Pages */
          <>
            {activeTab === 'discover' && (
              <DiscoverPage
                onOpenMessage={handleOpenChat}
                onNavigateToSkills={() => setActiveTab('skills')}
              />
            )}
            {activeTab === 'skills' && <SkillsPage />}
            {activeTab === 'bookings' && <BookingsPage />}
            {activeTab === 'messages' && (
              <MessagesPage initialPeerId={activeMessagePeerId} />
            )}
            {activeTab === 'profile' && <ProfileSettingsPage />}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950/80 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>SkillSwap • College Skill Exchange & Peer Tutoring Platform</span>
          <span className="font-mono text-[11px] text-slate-400">
            Real Database & Full-Stack API Operational
          </span>
        </div>
      </footer>

      {/* Auth Modal */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        defaultMode={authDefaultMode}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainContent />
    </AuthProvider>
  );
}
