import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  token: string | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (data: any) => Promise<void>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
  switchTestStudent: (email: string) => Promise<void>;
  demoStudents: Array<{ email: string; name: string; major: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('sk_token'));
  const [loading, setLoading] = useState<boolean>(true);
  const [demoStudents, setDemoStudents] = useState<Array<{ email: string; name: string; major: string }>>([]);

  const fetchCurrentUser = async (authToken?: string | null) => {
    const activeToken = authToken !== undefined ? authToken : token;
    try {
      const res = await fetch('/api/auth/me', {
        headers: activeToken ? { Authorization: `Bearer ${activeToken}` } : {},
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
      } else {
        setUser(null);
        if (activeToken) {
          localStorage.removeItem('sk_token');
          setToken(null);
        }
      }
    } catch (err) {
      console.error('Failed to fetch auth user:', err);
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  const fetchDemoStudents = async () => {
    try {
      const res = await fetch('/api/test-students');
      if (res.ok) {
        const data = await res.json();
        setDemoStudents(data.students || []);
      }
    } catch (err) {
      console.error('Failed to fetch demo students:', err);
    }
  };

  useEffect(() => {
    fetchCurrentUser();
    fetchDemoStudents();
  }, []);

  const login = async (email: string, password: string) => {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Login failed.');
    }

    localStorage.setItem('sk_token', data.token);
    setToken(data.token);
    await fetchCurrentUser(data.token);
  };

  const register = async (formData: any) => {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Registration failed.');
    }

    localStorage.setItem('sk_token', data.token);
    setToken(data.token);
    await fetchCurrentUser(data.token);
  };

  const logout = async () => {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
    } catch (err) {
      console.error('Logout error:', err);
    } finally {
      localStorage.removeItem('sk_token');
      setToken(null);
      setUser(null);
    }
  };

  const refreshUser = async () => {
    await fetchCurrentUser();
  };

  const switchTestStudent = async (email: string) => {
    await login(email, 'password123');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        login,
        register,
        logout,
        refreshUser,
        switchTestStudent,
        demoStudents,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider');
  return ctx;
}
