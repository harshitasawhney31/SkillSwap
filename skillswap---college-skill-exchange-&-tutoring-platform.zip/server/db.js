import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { calculateCompatibility } from './matching.js';
import { validateBookingRequest, validateStatusTransition } from './bookingRules.js';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'skillswap-store.json');

let dbState = null;

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function saveDb() {
  ensureDataDir();
  const tmpFile = `${DB_FILE}.tmp.${Date.now()}`;
  fs.writeFileSync(tmpFile, JSON.stringify(dbState, null, 2), 'utf-8');
  fs.renameSync(tmpFile, DB_FILE);
}

function loadDb() {
  ensureDataDir();
  if (fs.existsSync(DB_FILE)) {
    try {
      const data = fs.readFileSync(DB_FILE, 'utf-8');
      dbState = JSON.parse(data);
      return;
    } catch (err) {
      console.error('Failed to parse database file, reinitializing', err);
    }
  }

  // Initial Seed Data with distinct student profiles
  const salt = bcrypt.genSaltSync(10);
  const defaultPasswordHash = bcrypt.hashSync('password123', salt);

  const studentAId = 'usr-alex-001';
  const studentBId = 'usr-priya-002';
  const studentCId = 'usr-jordan-003';
  const studentDId = 'usr-marcus-004';

  dbState = {
    users: [
      {
        id: studentAId,
        email: 'alex.rivera@university.edu',
        passwordHash: defaultPasswordHash,
        name: 'Alex Rivera',
        university: 'California State University',
        major: 'Computer Science',
        graduationYear: 2026,
        bio: 'Senior CS student passionate about systems programming and game dev. Teaching C++ and Data Structures; looking to get better at React and UI design.',
        avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        role: 'STUDENT',
        averageRating: 4.9,
        totalReviews: 8,
        createdAt: new Date('2026-09-01T10:00:00Z').toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: studentBId,
        email: 'priya.patel@university.edu',
        passwordHash: defaultPasswordHash,
        name: 'Priya Patel',
        university: 'California State University',
        major: 'Software Engineering',
        graduationYear: 2027,
        bio: 'Frontend enthusiast with 3 years of building full-stack web applications. Love teaching modern React, Tailwind, and TypeScript. Eager to master C++ systems!',
        avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
        role: 'STUDENT',
        averageRating: 4.8,
        totalReviews: 6,
        createdAt: new Date('2026-09-02T10:00:00Z').toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: studentCId,
        email: 'jordan.lee@university.edu',
        passwordHash: defaultPasswordHash,
        name: 'Jordan Lee',
        university: 'California State University',
        major: 'Applied Mathematics',
        graduationYear: 2026,
        bio: 'Math major specializing in Linear Algebra and Multivariable Calculus. Happy to help STEM students conquer math requirements! Wanting to learn Python for data analysis.',
        avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        role: 'STUDENT',
        averageRating: 5.0,
        totalReviews: 4,
        createdAt: new Date('2026-09-03T10:00:00Z').toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: studentDId,
        email: 'marcus.chen@university.edu',
        passwordHash: defaultPasswordHash,
        name: 'Marcus Chen',
        university: 'California State University',
        major: 'Cognitive Science & UI/UX',
        graduationYear: 2027,
        bio: 'Interaction designer and Figma tutor. Teaching design systems, wireframing, and user research. Looking for Linear Algebra support for computer vision coursework.',
        avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
        role: 'STUDENT',
        averageRating: 4.7,
        totalReviews: 5,
        createdAt: new Date('2026-09-04T10:00:00Z').toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ],
    skills: [
      {
        id: 'sk-1',
        userId: studentAId,
        name: 'C++',
        category: 'Computer Science',
        proficiency: 'EXPERT',
        description: 'Memory management, pointers, STL containers, and algorithm design.',
        createdAt: new Date('2026-09-01T11:00:00Z').toISOString(),
      },
      {
        id: 'sk-2',
        userId: studentAId,
        name: 'Data Structures & Algorithms',
        category: 'Computer Science',
        proficiency: 'ADVANCED',
        description: 'Binary trees, graphs, dynamic programming, and Big-O analysis.',
        createdAt: new Date('2026-09-01T11:05:00Z').toISOString(),
      },
      {
        id: 'sk-3',
        userId: studentBId,
        name: 'React',
        category: 'Computer Science',
        proficiency: 'ADVANCED',
        description: 'Hooks, component lifecycle, state management, and modern React patterns.',
        createdAt: new Date('2026-09-02T11:00:00Z').toISOString(),
      },
      {
        id: 'sk-4',
        userId: studentBId,
        name: 'Tailwind CSS',
        category: 'Design & Frontend',
        proficiency: 'EXPERT',
        description: 'Utility-first styling, responsive layouts, and accessible component theming.',
        createdAt: new Date('2026-09-02T11:10:00Z').toISOString(),
      },
      {
        id: 'sk-5',
        userId: studentCId,
        name: 'Linear Algebra',
        category: 'Mathematics',
        proficiency: 'EXPERT',
        description: 'Vector spaces, eigenvalues, matrix transformations, and dot products.',
        createdAt: new Date('2026-09-03T11:00:00Z').toISOString(),
      },
      {
        id: 'sk-6',
        userId: studentDId,
        name: 'Figma UI/UX',
        category: 'Design & Frontend',
        proficiency: 'EXPERT',
        description: 'Auto-layout, interactive prototypes, component variants, and usability testing.',
        createdAt: new Date('2026-09-04T11:00:00Z').toISOString(),
      },
    ],
    learningGoals: [
      {
        id: 'lg-1',
        userId: studentAId,
        name: 'React',
        category: 'Computer Science',
        desiredLevel: 'INTERMEDIATE',
        priority: 'HIGH',
        notes: 'Want to build interactive web apps for my capstone project.',
        createdAt: new Date('2026-09-01T11:30:00Z').toISOString(),
      },
      {
        id: 'lg-2',
        userId: studentAId,
        name: 'Figma UI/UX',
        category: 'Design & Frontend',
        desiredLevel: 'BEGINNER',
        priority: 'MEDIUM',
        notes: 'Need to prototype modern student dashboards.',
        createdAt: new Date('2026-09-01T11:35:00Z').toISOString(),
      },
      {
        id: 'lg-3',
        userId: studentBId,
        name: 'C++',
        category: 'Computer Science',
        desiredLevel: 'INTERMEDIATE',
        priority: 'HIGH',
        notes: 'Preparing for technical interview rounds in systems engineering.',
        createdAt: new Date('2026-09-02T11:30:00Z').toISOString(),
      },
      {
        id: 'lg-4',
        userId: studentCId,
        name: 'Python',
        category: 'Computer Science',
        desiredLevel: 'BEGINNER',
        priority: 'HIGH',
        notes: 'Want to apply math formulas with NumPy and SciPy.',
        createdAt: new Date('2026-09-03T11:30:00Z').toISOString(),
      },
      {
        id: 'lg-5',
        userId: studentDId,
        name: 'Linear Algebra',
        category: 'Mathematics',
        desiredLevel: 'INTERMEDIATE',
        priority: 'HIGH',
        notes: 'Taking 3D graphics rendering course and need vector math review.',
        createdAt: new Date('2026-09-04T11:30:00Z').toISOString(),
      },
    ],
    availabilities: [
      { id: 'av-1', userId: studentAId, dayOfWeek: 2, startTime: '14:00', endTime: '18:00' }, // Tuesday
      { id: 'av-2', userId: studentAId, dayOfWeek: 4, startTime: '14:00', endTime: '18:00' }, // Thursday
      { id: 'av-3', userId: studentBId, dayOfWeek: 2, startTime: '15:00', endTime: '19:00' }, // Tuesday
      { id: 'av-4', userId: studentBId, dayOfWeek: 4, startTime: '15:00', endTime: '19:00' }, // Thursday
      { id: 'av-5', userId: studentCId, dayOfWeek: 1, startTime: '10:00', endTime: '14:00' }, // Monday
      { id: 'av-6', userId: studentCId, dayOfWeek: 3, startTime: '10:00', endTime: '14:00' }, // Wednesday
      { id: 'av-7', userId: studentDId, dayOfWeek: 1, startTime: '11:00', endTime: '15:00' }, // Monday
      { id: 'av-8', userId: studentDId, dayOfWeek: 3, startTime: '11:00', endTime: '15:00' }, // Wednesday
    ],
    bookings: [
      {
        id: 'bk-sample-01',
        requesterId: studentCId,
        recipientId: studentDId,
        skillName: 'Figma UI/UX',
        topic: 'Wireframing math dashboard interface',
        proposedDate: '2026-10-15',
        startTime: '11:00',
        endTime: '12:00',
        status: 'COMPLETED',
        notes: 'Great hands-on practice session with Figma auto-layouts.',
        meetingUrl: 'https://meet.google.com/xyz-peer-swap',
        createdAt: new Date('2026-10-10T10:00:00Z').toISOString(),
        updatedAt: new Date('2026-10-15T12:00:00Z').toISOString(),
      },
    ],
    messages: [
      {
        id: 'msg-01',
        senderId: studentBId,
        recipientId: studentAId,
        content: 'Hey Alex! I saw you are teaching C++ and want to learn React. Would you be down for a peer swap session next Tuesday?',
        read: true,
        createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
      },
      {
        id: 'msg-02',
        senderId: studentAId,
        recipientId: studentBId,
        content: 'Hi Priya! Absolutely, that sounds awesome. I have a session request ready for Tuesday afternoon.',
        read: true,
        createdAt: new Date(Date.now() - 3600000 * 1).toISOString(),
      },
    ],
    reviews: [
      {
        id: 'rev-01',
        bookingId: 'bk-sample-01',
        reviewerId: studentCId,
        revieweeId: studentDId,
        rating: 5,
        feedback: 'Marcus is an incredible design tutor! Explained Figma component variants and spacing in a super clear way.',
        createdAt: new Date('2026-10-15T13:00:00Z').toISOString(),
      },
    ],
    notifications: [
      {
        id: 'notif-01',
        userId: studentAId,
        type: 'NEW_MESSAGE',
        title: 'New message from Priya Patel',
        message: 'Hey Alex! I saw you are teaching C++...',
        link: '/messages',
        read: false,
        createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
      },
    ],
    preferences: [
      {
        id: 'pref-1',
        userId: studentAId,
        emailNotifications: true,
        sessionReminders: true,
        allowMatching: true,
        preferredMeeting: 'Virtual',
      },
      {
        id: 'pref-2',
        userId: studentBId,
        emailNotifications: true,
        sessionReminders: true,
        allowMatching: true,
        preferredMeeting: 'Virtual',
      },
      {
        id: 'pref-3',
        userId: studentCId,
        emailNotifications: true,
        sessionReminders: true,
        allowMatching: true,
        preferredMeeting: 'Campus Library',
      },
      {
        id: 'pref-4',
        userId: studentDId,
        emailNotifications: true,
        sessionReminders: true,
        allowMatching: true,
        preferredMeeting: 'Student Center',
      },
    ],
    sessions: [],
  };

  saveDb();
}

// Initialize on module import
loadDb();

function getDb() {
  if (!dbState) loadDb();
  return dbState;
}

// Public API
export const db = {
  // USER / AUTH
  createUser({ email, password, name, university, major, graduationYear, bio, avatarUrl }) {
    const state = getDb();
    const normalizedEmail = email.trim().toLowerCase();
    const existing = state.users.find(u => u.email.toLowerCase() === normalizedEmail);
    if (existing) {
      throw new Error('An account with this email address already exists.');
    }

    const salt = bcrypt.genSaltSync(10);
    const passwordHash = bcrypt.hashSync(password, salt);
    const userId = `usr-${crypto.randomUUID()}`;

    const newUser = {
      id: userId,
      email: normalizedEmail,
      passwordHash,
      name: name.trim(),
      university: (university || 'State University').trim(),
      major: (major || 'Computer Science').trim(),
      graduationYear: Number(graduationYear) || 2027,
      bio: (bio || '').trim(),
      avatarUrl: avatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(name.trim())}`,
      role: 'STUDENT',
      averageRating: 0.0,
      totalReviews: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    state.users.push(newUser);

    // Default preference
    state.preferences.push({
      id: `pref-${crypto.randomUUID()}`,
      userId,
      emailNotifications: true,
      sessionReminders: true,
      allowMatching: true,
      preferredMeeting: 'Virtual',
    });

    saveDb();
    const { passwordHash: _, ...safeUser } = newUser;
    return safeUser;
  },

  authenticateUser(email, password) {
    const state = getDb();
    const normalizedEmail = (email || '').trim().toLowerCase();
    const user = state.users.find(u => u.email.toLowerCase() === normalizedEmail);
    if (!user) {
      throw new Error('Invalid email or password.');
    }

    const matches = bcrypt.compareSync(password, user.passwordHash);
    if (!matches) {
      throw new Error('Invalid email or password.');
    }

    const sessionToken = `sk_sess_${crypto.randomBytes(32).toString('hex')}`;
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();

    state.sessions.push({
      token: sessionToken,
      userId: user.id,
      createdAt: new Date().toISOString(),
      expiresAt,
    });

    saveDb();
    const { passwordHash: _, ...safeUser } = user;
    return { user: safeUser, token: sessionToken };
  },

  getUserBySession(token) {
    if (!token) return null;
    const state = getDb();
    const session = state.sessions.find(s => s.token === token);
    if (!session) return null;

    if (new Date(session.expiresAt) < new Date()) {
      state.sessions = state.sessions.filter(s => s.token !== token);
      saveDb();
      return null;
    }

    const user = state.users.find(u => u.id === session.userId);
    if (!user) return null;

    const { passwordHash: _, ...safeUser } = user;
    return safeUser;
  },

  destroySession(token) {
    const state = getDb();
    state.sessions = state.sessions.filter(s => s.token !== token);
    saveDb();
  },

  getUserById(userId) {
    const state = getDb();
    const user = state.users.find(u => u.id === userId);
    if (!user) return null;
    const { passwordHash: _, ...safeUser } = user;
    return safeUser;
  },

  getFullUserProfile(userId) {
    const state = getDb();
    const user = state.users.find(u => u.id === userId);
    if (!user) return null;

    const teachingSkills = state.skills.filter(s => s.userId === userId);
    const learningGoals = state.learningGoals.filter(g => g.userId === userId);
    const availabilities = state.availabilities.filter(a => a.userId === userId);
    const preferences = state.preferences.find(p => p.userId === userId) || {
      emailNotifications: true,
      sessionReminders: true,
      allowMatching: true,
      preferredMeeting: 'Virtual',
    };
    const reviewsReceived = state.reviews.filter(r => r.revieweeId === userId);

    const { passwordHash: _, ...safeUser } = user;
    return {
      ...safeUser,
      teachingSkills,
      learningGoals,
      availabilities,
      preferences,
      reviewsReceived,
    };
  },

  updateUserProfile(userId, updates) {
    const state = getDb();
    const user = state.users.find(u => u.id === userId);
    if (!user) throw new Error('User not found');

    if (updates.name) user.name = updates.name.trim();
    if (updates.university) user.university = updates.university.trim();
    if (updates.major) user.major = updates.major.trim();
    if (updates.graduationYear) user.graduationYear = Number(updates.graduationYear);
    if (updates.bio !== undefined) user.bio = updates.bio.trim();
    if (updates.avatarUrl) user.avatarUrl = updates.avatarUrl.trim();

    user.updatedAt = new Date().toISOString();
    saveDb();
    const { passwordHash: _, ...safeUser } = user;
    return safeUser;
  },

  changeUserPassword(userId, currentPassword, newPassword) {
    const state = getDb();
    const user = state.users.find(u => u.id === userId);
    if (!user) throw new Error('User not found');

    const matches = bcrypt.compareSync(currentPassword, user.passwordHash);
    if (!matches) {
      throw new Error('Current password does not match.');
    }

    if (!newPassword || newPassword.length < 6) {
      throw new Error('New password must be at least 6 characters.');
    }

    const salt = bcrypt.genSaltSync(10);
    user.passwordHash = bcrypt.hashSync(newPassword, salt);
    user.updatedAt = new Date().toISOString();
    saveDb();
    return true;
  },

  deleteUserAccount(userId) {
    const state = getDb();
    state.users = state.users.filter(u => u.id !== userId);
    state.skills = state.skills.filter(s => s.userId !== userId);
    state.learningGoals = state.learningGoals.filter(g => g.userId !== userId);
    state.availabilities = state.availabilities.filter(a => a.userId !== userId);
    state.bookings = state.bookings.filter(b => b.requesterId !== userId && b.recipientId !== userId);
    state.messages = state.messages.filter(m => m.senderId !== userId && m.recipientId !== userId);
    state.reviews = state.reviews.filter(r => r.reviewerId !== userId && r.revieweeId !== userId);
    state.notifications = state.notifications.filter(n => n.userId !== userId);
    state.preferences = state.preferences.filter(p => p.userId !== userId);
    state.sessions = state.sessions.filter(s => s.userId !== userId);
    saveDb();
    return true;
  },

  // SKILLS MANAGEMENT
  getUserSkills(userId) {
    const state = getDb();
    return state.skills.filter(s => s.userId === userId);
  },

  createSkill(userId, { name, category, proficiency, description }) {
    if (!name || !name.trim()) throw new Error('Skill name is required.');
    const state = getDb();
    const newSkill = {
      id: `sk-${crypto.randomUUID()}`,
      userId,
      name: name.trim(),
      category: (category || 'General').trim(),
      proficiency: proficiency || 'INTERMEDIATE',
      description: (description || '').trim(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    state.skills.push(newSkill);
    saveDb();
    return newSkill;
  },

  updateSkill(userId, skillId, updates) {
    const state = getDb();
    const skill = state.skills.find(s => s.id === skillId);
    if (!skill) throw new Error('Skill not found.');
    if (skill.userId !== userId) throw new Error('Unauthorized: You do not own this skill.');

    if (updates.name) skill.name = updates.name.trim();
    if (updates.category) skill.category = updates.category.trim();
    if (updates.proficiency) skill.proficiency = updates.proficiency;
    if (updates.description !== undefined) skill.description = updates.description.trim();
    skill.updatedAt = new Date().toISOString();

    saveDb();
    return skill;
  },

  deleteSkill(userId, skillId) {
    const state = getDb();
    const skill = state.skills.find(s => s.id === skillId);
    if (!skill) throw new Error('Skill not found.');
    if (skill.userId !== userId) throw new Error('Unauthorized: You do not own this skill.');

    state.skills = state.skills.filter(s => s.id !== skillId);
    saveDb();
    return true;
  },

  // LEARNING GOALS MANAGEMENT
  getUserGoals(userId) {
    const state = getDb();
    return state.learningGoals.filter(g => g.userId === userId);
  },

  createGoal(userId, { name, category, desiredLevel, priority, notes }) {
    if (!name || !name.trim()) throw new Error('Learning goal name is required.');
    const state = getDb();
    const newGoal = {
      id: `lg-${crypto.randomUUID()}`,
      userId,
      name: name.trim(),
      category: (category || 'General').trim(),
      desiredLevel: desiredLevel || 'INTERMEDIATE',
      priority: priority || 'MEDIUM',
      notes: (notes || '').trim(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    state.learningGoals.push(newGoal);
    saveDb();
    return newGoal;
  },

  updateGoal(userId, goalId, updates) {
    const state = getDb();
    const goal = state.learningGoals.find(g => g.id === goalId);
    if (!goal) throw new Error('Learning goal not found.');
    if (goal.userId !== userId) throw new Error('Unauthorized: You do not own this learning goal.');

    if (updates.name) goal.name = updates.name.trim();
    if (updates.category) goal.category = updates.category.trim();
    if (updates.desiredLevel) goal.desiredLevel = updates.desiredLevel;
    if (updates.priority) goal.priority = updates.priority;
    if (updates.notes !== undefined) goal.notes = updates.notes.trim();
    goal.updatedAt = new Date().toISOString();

    saveDb();
    return goal;
  },

  deleteGoal(userId, goalId) {
    const state = getDb();
    const goal = state.learningGoals.find(g => g.id === goalId);
    if (!goal) throw new Error('Learning goal not found.');
    if (goal.userId !== userId) throw new Error('Unauthorized: You do not own this learning goal.');

    state.learningGoals = state.learningGoals.filter(g => g.id !== goalId);
    saveDb();
    return true;
  },

  // Skill swap transformation (Goal -> Teaching Skill or Teaching Skill -> Goal)
  convertGoalToSkill(userId, goalId, { proficiency = 'INTERMEDIATE', description = '' }) {
    const state = getDb();
    const goal = state.learningGoals.find(g => g.id === goalId && g.userId === userId);
    if (!goal) throw new Error('Goal not found.');

    state.learningGoals = state.learningGoals.filter(g => g.id !== goalId);
    const newSkill = {
      id: `sk-${crypto.randomUUID()}`,
      userId,
      name: goal.name,
      category: goal.category,
      proficiency,
      description: description || goal.notes || `Transformed from learning goal: ${goal.name}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    state.skills.push(newSkill);
    saveDb();
    return newSkill;
  },

  convertSkillToGoal(userId, skillId, { desiredLevel = 'ADVANCED', priority = 'HIGH', notes = '' }) {
    const state = getDb();
    const skill = state.skills.find(s => s.id === skillId && s.userId === userId);
    if (!skill) throw new Error('Skill not found.');

    state.skills = state.skills.filter(s => s.id !== skillId);
    const newGoal = {
      id: `lg-${crypto.randomUUID()}`,
      userId,
      name: skill.name,
      category: skill.category,
      desiredLevel,
      priority,
      notes: notes || skill.description || `Transformed from teaching skill: ${skill.name}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    state.learningGoals.push(newGoal);
    saveDb();
    return newGoal;
  },

  // AVAILABILITY
  getAvailabilities(userId) {
    const state = getDb();
    return state.availabilities.filter(a => a.userId === userId);
  },

  setAvailabilities(userId, slots) {
    const state = getDb();
    state.availabilities = state.availabilities.filter(a => a.userId !== userId);
    for (const slot of slots) {
      state.availabilities.push({
        id: `av-${crypto.randomUUID()}`,
        userId,
        dayOfWeek: Number(slot.dayOfWeek),
        startTime: slot.startTime,
        endTime: slot.endTime,
        createdAt: new Date().toISOString(),
      });
    }
    saveDb();
    return state.availabilities.filter(a => a.userId === userId);
  },

  // DISCOVER & MATCHING
  getDiscoveredPeers(currentUserId, query = {}) {
    const state = getDb();
    const currentUser = state.users.find(u => u.id === currentUserId);
    if (!currentUser) throw new Error('Current user not found.');

    const currentUserSkills = state.skills.filter(s => s.userId === currentUserId);
    const currentUserGoals = state.learningGoals.filter(g => g.userId === currentUserId);
    const currentUserAvail = state.availabilities.filter(a => a.userId === currentUserId);

    const currentUserData = {
      ...currentUser,
      teachingSkills: currentUserSkills,
      learningGoals: currentUserGoals,
      availabilities: currentUserAvail,
    };

    // Filter peers excluding current user
    const otherUsers = state.users.filter(u => u.id !== currentUserId);

    const results = otherUsers.map(peer => {
      const peerSkills = state.skills.filter(s => s.userId === peer.id);
      const peerGoals = state.learningGoals.filter(g => g.userId === peer.id);
      const peerAvail = state.availabilities.filter(a => a.userId === peer.id);

      const peerData = {
        ...peer,
        teachingSkills: peerSkills,
        learningGoals: peerGoals,
        availabilities: peerAvail,
      };

      const match = calculateCompatibility(currentUserData, peerData);
      const { passwordHash: _, ...safePeer } = peer;

      return {
        ...safePeer,
        teachingSkills: peerSkills,
        learningGoals: peerGoals,
        availabilities: peerAvail,
        matchScore: match.score,
        matchReasons: match.reasons,
        isReciprocal: match.isReciprocal,
        matchedTheyTeach: match.matchedTheyTeach,
        matchedYouTeach: match.matchedYouTeach,
      };
    });

    // Optional category / skill filter
    let filtered = results;
    if (query.skill) {
      const q = query.skill.toLowerCase();
      filtered = filtered.filter(p =>
        p.teachingSkills.some(s => s.name.toLowerCase().includes(q)) ||
        p.learningGoals.some(g => g.name.toLowerCase().includes(q))
      );
    }
    if (query.category) {
      const cat = query.category.toLowerCase();
      filtered = filtered.filter(p =>
        p.teachingSkills.some(s => s.category.toLowerCase() === cat)
      );
    }

    // Sort by match score descending, then rating descending
    filtered.sort((a, b) => {
      if (b.matchScore !== a.matchScore) return b.matchScore - a.matchScore;
      return b.averageRating - a.averageRating;
    });

    return filtered;
  },

  // BOOKINGS & CALENDAR
  getBookingsForUser(userId) {
    const state = getDb();
    const userBookings = state.bookings.filter(b => b.requesterId === userId || b.recipientId === userId);

    return userBookings.map(b => {
      const requester = state.users.find(u => u.id === b.requesterId);
      const recipient = state.users.find(u => u.id === b.recipientId);
      const reviewGiven = state.reviews.find(r => r.bookingId === b.id && r.reviewerId === userId);

      return {
        ...b,
        requester: requester ? { id: requester.id, name: requester.name, email: requester.email, avatarUrl: requester.avatarUrl, major: requester.major, university: requester.university } : null,
        recipient: recipient ? { id: recipient.id, name: recipient.name, email: recipient.email, avatarUrl: recipient.avatarUrl, major: recipient.major, university: recipient.university } : null,
        userRole: b.requesterId === userId ? 'REQUESTER' : 'RECIPIENT',
        hasReviewed: Boolean(reviewGiven),
      };
    }).sort((a, b) => new Date(`${b.proposedDate}T${b.startTime}`).getTime() - new Date(`${a.proposedDate}T${a.startTime}`).getTime());
  },

  createBookingRequest(requesterId, bookingData) {
    const state = getDb();
    const dataWithRequester = { ...bookingData, requesterId };

    const validation = validateBookingRequest(dataWithRequester, state.bookings);
    if (!validation.valid) {
      throw new Error(validation.error);
    }

    const bookingId = `bk-${crypto.randomUUID()}`;
    const newBooking = {
      id: bookingId,
      requesterId,
      recipientId: bookingData.recipientId,
      skillName: bookingData.skillName.trim(),
      topic: (bookingData.topic || `Peer session for ${bookingData.skillName}`).trim(),
      proposedDate: bookingData.proposedDate,
      startTime: bookingData.startTime,
      endTime: bookingData.endTime,
      status: 'PENDING',
      notes: (bookingData.notes || '').trim(),
      meetingUrl: bookingData.meetingUrl || `https://meet.google.com/${crypto.randomBytes(4).toString('hex')}-${crypto.randomBytes(4).toString('hex')}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    state.bookings.push(newBooking);

    // Notify recipient
    const requester = state.users.find(u => u.id === requesterId);
    state.notifications.push({
      id: `notif-${crypto.randomUUID()}`,
      userId: bookingData.recipientId,
      type: 'BOOKING_REQUEST',
      title: `New Session Request from ${requester?.name || 'a peer'}`,
      message: `${requester?.name || 'A student'} proposed a session for ${newBooking.skillName} on ${newBooking.proposedDate} at ${newBooking.startTime}.`,
      link: '/bookings',
      read: false,
      createdAt: new Date().toISOString(),
    });

    saveDb();
    return newBooking;
  },

  updateBookingStatus(userId, bookingId, newStatus) {
    const state = getDb();
    const booking = state.bookings.find(b => b.id === bookingId);
    if (!booking) throw new Error('Booking not found.');

    const transition = validateStatusTransition(booking, newStatus, userId, state.bookings);
    if (!transition.allowed) {
      throw new Error(transition.error);
    }

    booking.status = newStatus;
    booking.updatedAt = new Date().toISOString();

    const otherUserId = booking.requesterId === userId ? booking.recipientId : booking.requesterId;
    const actor = state.users.find(u => u.id === userId);

    let notifType = 'SYSTEM';
    let notifMsg = `Session status updated to ${newStatus}`;

    if (newStatus === 'ACCEPTED') {
      notifType = 'BOOKING_ACCEPTED';
      notifMsg = `${actor?.name || 'Your peer'} accepted your session request for ${booking.skillName}!`;
    } else if (newStatus === 'REJECTED') {
      notifType = 'BOOKING_REJECTED';
      notifMsg = `${actor?.name || 'Your peer'} declined the session request for ${booking.skillName}.`;
    } else if (newStatus === 'CANCELLED') {
      notifType = 'BOOKING_CANCELLED';
      notifMsg = `${actor?.name || 'Your peer'} cancelled the scheduled session for ${booking.skillName}.`;
    } else if (newStatus === 'COMPLETED') {
      notifType = 'BOOKING_COMPLETED';
      notifMsg = `The session for ${booking.skillName} has been marked completed. You can now leave a review!`;
    }

    state.notifications.push({
      id: `notif-${crypto.randomUUID()}`,
      userId: otherUserId,
      type: notifType,
      title: `Session ${newStatus.toLowerCase()}: ${booking.skillName}`,
      message: notifMsg,
      link: '/bookings',
      read: false,
      createdAt: new Date().toISOString(),
    });

    saveDb();
    return booking;
  },

  // MESSAGING
  sendMessage(senderId, recipientId, content) {
    if (!content || !content.trim()) throw new Error('Message content cannot be empty.');
    if (senderId === recipientId) throw new Error('Cannot send messages to yourself.');

    const state = getDb();
    const recipient = state.users.find(u => u.id === recipientId);
    if (!recipient) throw new Error('Recipient user does not exist.');

    const newMsg = {
      id: `msg-${crypto.randomUUID()}`,
      senderId,
      recipientId,
      content: content.trim(),
      read: false,
      createdAt: new Date().toISOString(),
    };

    state.messages.push(newMsg);

    const sender = state.users.find(u => u.id === senderId);
    state.notifications.push({
      id: `notif-${crypto.randomUUID()}`,
      userId: recipientId,
      type: 'NEW_MESSAGE',
      title: `Message from ${sender?.name || 'Student'}`,
      message: newMsg.content.slice(0, 100),
      link: '/messages',
      read: false,
      createdAt: new Date().toISOString(),
    });

    saveDb();
    return newMsg;
  },

  getConversation(userId, peerId) {
    const state = getDb();
    return state.messages.filter(m =>
      (m.senderId === userId && m.recipientId === peerId) ||
      (m.senderId === peerId && m.recipientId === userId)
    ).sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  },

  markConversationRead(userId, peerId) {
    const state = getDb();
    let updated = false;
    for (const msg of state.messages) {
      if (msg.senderId === peerId && msg.recipientId === userId && !msg.read) {
        msg.read = true;
        updated = true;
      }
    }
    if (updated) saveDb();
    return true;
  },

  getConversationsList(userId) {
    const state = getDb();
    const peerMap = new Map();

    const userMsgs = state.messages.filter(m => m.senderId === userId || m.recipientId === userId);

    for (const msg of userMsgs) {
      const peerId = msg.senderId === userId ? msg.recipientId : msg.senderId;
      if (!peerMap.has(peerId)) {
        peerMap.set(peerId, {
          peerId,
          lastMessage: msg,
          unreadCount: 0,
        });
      } else {
        const item = peerMap.get(peerId);
        if (new Date(msg.createdAt) > new Date(item.lastMessage.createdAt)) {
          item.lastMessage = msg;
        }
      }
      if (msg.recipientId === userId && !msg.read) {
        const item = peerMap.get(peerId);
        item.unreadCount += 1;
      }
    }

    const conversations = [];
    for (const [peerId, data] of peerMap.entries()) {
      const peer = state.users.find(u => u.id === peerId);
      if (peer) {
        conversations.push({
          peer: {
            id: peer.id,
            name: peer.name,
            email: peer.email,
            avatarUrl: peer.avatarUrl,
            major: peer.major,
          },
          lastMessage: data.lastMessage,
          unreadCount: data.unreadCount,
        });
      }
    }

    return conversations.sort((a, b) => new Date(b.lastMessage.createdAt).getTime() - new Date(a.lastMessage.createdAt).getTime());
  },

  // REVIEWS & RATINGS
  createReview(reviewerId, { bookingId, rating, feedback }) {
    const state = getDb();
    const booking = state.bookings.find(b => b.id === bookingId);
    if (!booking) throw new Error('Session booking not found.');

    if (booking.status !== 'COMPLETED') {
      throw new Error('You can only review completed sessions.');
    }

    const isRequester = booking.requesterId === reviewerId;
    const isRecipient = booking.recipientId === reviewerId;
    if (!isRequester && !isRecipient) {
      throw new Error('Unauthorized: You did not participate in this session.');
    }

    const existingReview = state.reviews.find(r => r.bookingId === bookingId && r.reviewerId === reviewerId);
    if (existingReview) {
      throw new Error('You have already submitted a review for this session.');
    }

    const numRating = Number(rating);
    if (isNaN(numRating) || numRating < 1 || numRating > 5) {
      throw new Error('Rating must be an integer between 1 and 5 stars.');
    }

    const revieweeId = isRequester ? booking.recipientId : booking.requesterId;
    const reviewId = `rev-${crypto.randomUUID()}`;

    const newReview = {
      id: reviewId,
      bookingId,
      reviewerId,
      revieweeId,
      rating: numRating,
      feedback: (feedback || '').trim(),
      createdAt: new Date().toISOString(),
    };

    state.reviews.push(newReview);

    // Recalculate reviewee average rating and total count from real DB
    const revieweeReviews = state.reviews.filter(r => r.revieweeId === revieweeId);
    const sumRatings = revieweeReviews.reduce((sum, r) => sum + r.rating, 0);
    const avgRating = revieweeReviews.length > 0 ? Number((sumRatings / revieweeReviews.length).toFixed(1)) : 0.0;

    const revieweeUser = state.users.find(u => u.id === revieweeId);
    if (revieweeUser) {
      revieweeUser.averageRating = avgRating;
      revieweeUser.totalReviews = revieweeReviews.length;
    }

    // Notify reviewee
    const reviewer = state.users.find(u => u.id === reviewerId);
    state.notifications.push({
      id: `notif-${crypto.randomUUID()}`,
      userId: revieweeId,
      type: 'NEW_REVIEW',
      title: `New Review from ${reviewer?.name || 'A Student'}`,
      message: `Received ${numRating} stars: "${newReview.feedback.slice(0, 80)}"`,
      link: '/profile',
      read: false,
      createdAt: new Date().toISOString(),
    });

    saveDb();
    return newReview;
  },

  getUserReviews(userId) {
    const state = getDb();
    const reviews = state.reviews.filter(r => r.revieweeId === userId);
    return reviews.map(r => {
      const reviewer = state.users.find(u => u.id === r.reviewerId);
      const booking = state.bookings.find(b => b.id === r.bookingId);
      return {
        ...r,
        reviewer: reviewer ? { id: reviewer.id, name: reviewer.name, avatarUrl: reviewer.avatarUrl, major: reviewer.major } : null,
        skillName: booking?.skillName || 'Skill Exchange',
      };
    }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },

  // NOTIFICATIONS
  getNotifications(userId) {
    const state = getDb();
    return state.notifications
      .filter(n => n.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },

  markNotificationRead(userId, notificationId) {
    const state = getDb();
    const notif = state.notifications.find(n => n.id === notificationId && n.userId === userId);
    if (notif) {
      notif.read = true;
      saveDb();
    }
    return true;
  },

  markAllNotificationsRead(userId) {
    const state = getDb();
    let updated = false;
    for (const n of state.notifications) {
      if (n.userId === userId && !n.read) {
        n.read = true;
        updated = true;
      }
    }
    if (updated) saveDb();
    return true;
  },

  // PREFERENCES
  getUserPreferences(userId) {
    const state = getDb();
    let pref = state.preferences.find(p => p.userId === userId);
    if (!pref) {
      pref = {
        id: `pref-${crypto.randomUUID()}`,
        userId,
        emailNotifications: true,
        sessionReminders: true,
        allowMatching: true,
        preferredMeeting: 'Virtual',
      };
      state.preferences.push(pref);
      saveDb();
    }
    return pref;
  },

  updateUserPreferences(userId, updates) {
    const state = getDb();
    let pref = state.preferences.find(p => p.userId === userId);
    if (!pref) {
      pref = {
        id: `pref-${crypto.randomUUID()}`,
        userId,
        emailNotifications: true,
        sessionReminders: true,
        allowMatching: true,
        preferredMeeting: 'Virtual',
      };
      state.preferences.push(pref);
    }

    if (updates.emailNotifications !== undefined) pref.emailNotifications = Boolean(updates.emailNotifications);
    if (updates.sessionReminders !== undefined) pref.sessionReminders = Boolean(updates.sessionReminders);
    if (updates.allowMatching !== undefined) pref.allowMatching = Boolean(updates.allowMatching);
    if (updates.preferredMeeting !== undefined) pref.preferredMeeting = updates.preferredMeeting;

    saveDb();
    return pref;
  },
};
