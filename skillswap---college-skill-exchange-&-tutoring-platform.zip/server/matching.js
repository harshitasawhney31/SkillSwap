/**
 * SkillSwap Reciprocal Matching Algorithm
 * Calculates compatibility score (0 - 100) and explicit reasons between two student profiles.
 */

const PROFICIENCY_RANK = {
  BEGINNER: 1,
  INTERMEDIATE: 2,
  ADVANCED: 3,
  EXPERT: 4,
};

function normalizeSkillName(name) {
  if (!name) return '';
  return name.trim().toLowerCase().replace(/[\s\-_.]+/g, '');
}

/**
 * Calculates matching compatibility between currentUser and candidateUser.
 * @param {Object} currentUser
 * @param {Object} candidateUser
 * @returns {Object} { score: number, reasons: string[], isReciprocal: boolean, matchedTheyTeach: string[], matchedYouTeach: string[] }
 */
export function calculateCompatibility(currentUser, candidateUser) {
  if (!currentUser || !candidateUser || currentUser.id === candidateUser.id) {
    return {
      score: 0,
      reasons: [],
      isReciprocal: false,
      matchedTheyTeach: [],
      matchedYouTeach: [],
    };
  }

  const userGoals = currentUser.learningGoals || [];
  const userTeaches = currentUser.teachingSkills || [];
  const candidateGoals = candidateUser.learningGoals || [];
  const candidateTeaches = candidateUser.teachingSkills || [];

  // Check what candidate can teach current user
  const theyTeachYou = [];
  let proficiencyBonus = 0;

  for (const goal of userGoals) {
    const goalNorm = normalizeSkillName(goal.name);
    for (const skill of candidateTeaches) {
      const skillNorm = normalizeSkillName(skill.name);
      if (goalNorm && (goalNorm === skillNorm || goalNorm.includes(skillNorm) || skillNorm.includes(goalNorm))) {
        theyTeachYou.push({
          skillName: skill.name,
          theirProficiency: skill.proficiency,
          yourDesired: goal.desiredLevel,
        });

        const theirRank = PROFICIENCY_RANK[skill.proficiency] || 2;
        const yourDesiredRank = PROFICIENCY_RANK[goal.desiredLevel] || 2;
        if (theirRank >= yourDesiredRank) {
          proficiencyBonus += 5;
        }
        break;
      }
    }
  }

  // Check what current user can teach candidate
  const youTeachThem = [];
  for (const candGoal of candidateGoals) {
    const goalNorm = normalizeSkillName(candGoal.name);
    for (const skill of userTeaches) {
      const skillNorm = normalizeSkillName(skill.name);
      if (goalNorm && (goalNorm === skillNorm || goalNorm.includes(skillNorm) || skillNorm.includes(goalNorm))) {
        youTeachThem.push({
          skillName: skill.name,
          yourProficiency: skill.proficiency,
          theirDesired: candGoal.desiredLevel,
        });
        break;
      }
    }
  }

  // If there is zero match in either direction, compatibility is 0
  if (theyTeachYou.length === 0 && youTeachThem.length === 0) {
    return {
      score: 0,
      reasons: [],
      isReciprocal: false,
      matchedTheyTeach: [],
      matchedYouTeach: [],
    };
  }

  const isReciprocal = theyTeachYou.length > 0 && youTeachThem.length > 0;
  let rawScore = 0;
  const reasons = [];

  if (isReciprocal) {
    rawScore += 40; // Reciprocal swap bonus
    const candidateSkillsStr = theyTeachYou.map(s => s.skillName).join(', ');
    const userSkillsStr = youTeachThem.map(s => s.skillName).join(', ');
    reasons.push(`Direct 2-way Swap: They teach ${candidateSkillsStr} and want to learn ${userSkillsStr} from you.`);
  }

  if (theyTeachYou.length > 0) {
    const teachCountPoints = Math.min(25, theyTeachYou.length * 20);
    rawScore += teachCountPoints;
    if (!isReciprocal) {
      reasons.push(`They teach ${theyTeachYou.map(s => s.skillName).join(', ')}, matching your learning goals.`);
    }
  }

  if (youTeachThem.length > 0) {
    const learnCountPoints = Math.min(25, youTeachThem.length * 20);
    rawScore += learnCountPoints;
    if (!isReciprocal) {
      reasons.push(`You can teach ${youTeachThem.map(s => s.skillName).join(', ')}, matching their learning goals.`);
    }
  }

  if (proficiencyBonus > 0) {
    rawScore += Math.min(10, proficiencyBonus);
    reasons.push('Proficiency alignment: Their skill level meets or exceeds your target.');
  }

  // Check shared availability
  const userAvail = currentUser.availabilities || [];
  const candAvail = candidateUser.availabilities || [];
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const sharedDays = [];

  for (const u of userAvail) {
    for (const c of candAvail) {
      if (u.dayOfWeek === c.dayOfWeek) {
        // Simple overlap check
        if (u.startTime < c.endTime && u.endTime > c.startTime) {
          const dayName = dayNames[u.dayOfWeek] || `Day ${u.dayOfWeek}`;
          if (!sharedDays.includes(dayName)) {
            sharedDays.push(dayName);
          }
        }
      }
    }
  }

  if (sharedDays.length > 0) {
    rawScore += 10;
    reasons.push(`Common availability on: ${sharedDays.join(', ')}.`);
  }

  // Ratings weight (up to 10 points)
  const rating = candidateUser.averageRating || 0;
  if (rating > 0) {
    const ratingPoints = Math.min(10, (rating / 5) * 10);
    rawScore += ratingPoints;
    if (rating >= 4.5) {
      reasons.push(`Highly rated tutor: ${rating.toFixed(1)} / 5.0 stars.`);
    }
  }

  const finalScore = Math.min(100, Math.max(0, Math.round(rawScore)));

  return {
    score: finalScore,
    reasons,
    isReciprocal,
    matchedTheyTeach: theyTeachYou.map(s => s.skillName),
    matchedYouTeach: youTeachThem.map(s => s.skillName),
  };
}
