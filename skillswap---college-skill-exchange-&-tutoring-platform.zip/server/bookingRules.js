/**
 * SkillSwap Booking Validation & Conflict Checking Rules
 */

export function parseMinutes(timeStr) {
  if (!timeStr || !timeStr.includes(':')) return 0;
  const [h, m] = timeStr.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

export function timesOverlap(startA, endA, startB, endB) {
  const aStart = parseMinutes(startA);
  const aEnd = parseMinutes(endA);
  const bStart = parseMinutes(startB);
  const bEnd = parseMinutes(endB);
  return aStart < bEnd && aEnd > bStart;
}

/**
 * Validates a new booking request.
 * @param {Object} bookingData
 * @param {Array} existingBookings All existing bookings in the system
 * @returns {{ valid: boolean, error?: string }}
 */
export function validateBookingRequest(bookingData, existingBookings = []) {
  const { requesterId, recipientId, proposedDate, startTime, endTime, skillName } = bookingData;

  if (!requesterId || !recipientId) {
    return { valid: false, error: 'Both requester and recipient are required.' };
  }

  if (requesterId === recipientId) {
    return { valid: false, error: 'Self-booking is not allowed. You cannot schedule a session with yourself.' };
  }

  if (!skillName || !skillName.trim()) {
    return { valid: false, error: 'Skill name to exchange is required.' };
  }

  if (!proposedDate || !startTime || !endTime) {
    return { valid: false, error: 'Proposed date, start time, and end time are required.' };
  }

  // Date format YYYY-MM-DD
  const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
  if (!dateRegex.test(proposedDate)) {
    return { valid: false, error: 'Invalid date format. Expected YYYY-MM-DD.' };
  }

  // Check past date
  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);
  if (proposedDate < todayStr) {
    return { valid: false, error: 'Cannot book sessions in the past.' };
  }

  const startMin = parseMinutes(startTime);
  const endMin = parseMinutes(endTime);

  if (endMin <= startMin) {
    return { valid: false, error: 'End time must be after start time.' };
  }

  const durationMin = endMin - startMin;
  if (durationMin < 15) {
    return { valid: false, error: 'Minimum session length is 15 minutes.' };
  }
  if (durationMin > 240) {
    return { valid: false, error: 'Maximum session length is 4 hours.' };
  }

  // Check conflicting accepted sessions for either participant
  for (const b of existingBookings) {
    if (b.status === 'ACCEPTED' && b.proposedDate === proposedDate) {
      const involvesRequester = b.requesterId === requesterId || b.recipientId === requesterId;
      const involvesRecipient = b.requesterId === recipientId || b.recipientId === recipientId;

      if ((involvesRequester || involvesRecipient) && timesOverlap(b.startTime, b.endTime, startTime, endTime)) {
        if (involvesRecipient) {
          return {
            valid: false,
            error: `Schedule conflict: The peer already has an accepted session on ${proposedDate} from ${b.startTime} to ${b.endTime}.`,
          };
        }
        return {
          valid: false,
          error: `Schedule conflict: You already have an accepted session on ${proposedDate} from ${b.startTime} to ${b.endTime}.`,
        };
      }
    }
  }

  return { valid: true };
}

/**
 * Validates a booking status transition.
 * @param {Object} booking
 * @param {string} newStatus
 * @param {string} userId Current authenticated user id
 * @param {Array} existingBookings
 * @returns {{ allowed: boolean, error?: string }}
 */
export function validateStatusTransition(booking, newStatus, userId, existingBookings = []) {
  if (!booking) return { allowed: false, error: 'Booking not found.' };

  const isRequester = booking.requesterId === userId;
  const isRecipient = booking.recipientId === userId;

  if (!isRequester && !isRecipient) {
    return { allowed: false, error: 'Unauthorized: You are not a participant in this booking.' };
  }

  if (booking.status === newStatus) {
    return { allowed: false, error: `Booking is already ${newStatus}.` };
  }

  if (booking.status === 'COMPLETED' || booking.status === 'CANCELLED' || booking.status === 'REJECTED') {
    return { allowed: false, error: `Cannot change status of a ${booking.status} booking.` };
  }

  if (newStatus === 'ACCEPTED') {
    if (!isRecipient) {
      return { allowed: false, error: 'Only the session recipient can accept a booking request.' };
    }
    // Check conflicts when accepting
    for (const b of existingBookings) {
      if (b.id !== booking.id && b.status === 'ACCEPTED' && b.proposedDate === booking.proposedDate) {
        const involvesRequester = b.requesterId === booking.requesterId || b.recipientId === booking.requesterId;
        const involvesRecipient = b.requesterId === booking.recipientId || b.recipientId === booking.recipientId;

        if ((involvesRequester || involvesRecipient) && timesOverlap(b.startTime, b.endTime, booking.startTime, booking.endTime)) {
          return {
            allowed: false,
            error: `Cannot accept: Overlaps with an already accepted session (${b.proposedDate} ${b.startTime}-${b.endTime}).`,
          };
        }
      }
    }
  } else if (newStatus === 'REJECTED') {
    if (!isRecipient) {
      return { allowed: false, error: 'Only the session recipient can reject a booking request.' };
    }
  } else if (newStatus === 'CANCELLED') {
    if (!isRequester && !isRecipient) {
      return { allowed: false, error: 'Unauthorized to cancel this session.' };
    }
  } else if (newStatus === 'COMPLETED') {
    if (booking.status !== 'ACCEPTED') {
      return { allowed: false, error: 'Only accepted sessions can be marked as completed.' };
    }
  } else {
    return { allowed: false, error: `Invalid target status: ${newStatus}` };
  }

  return { allowed: true };
}
